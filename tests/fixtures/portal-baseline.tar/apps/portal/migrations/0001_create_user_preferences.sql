create table saas_user_preferences (
  user_id text primary key,
  theme text not null default 'light'
    check (theme in ('light', 'dark')),
  sidebar_collapsed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table saas_user_app_preferences (
  user_id text not null
    references saas_user_preferences(user_id)
    on delete cascade,
  app_name text not null,
  hidden boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, app_name)
);
