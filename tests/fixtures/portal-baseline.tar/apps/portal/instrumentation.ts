export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { initializePortalRegistry } = await import("./lib/registry-runtime.ts");
    await initializePortalRegistry();
  }
}
