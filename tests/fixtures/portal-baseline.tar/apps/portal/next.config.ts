import type { NextConfig } from "next";

const allowedDevOrigins = (process.env.FRAME_ALLOWED_DEV_ORIGINS ?? "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

const nextConfig: NextConfig = {
  output: "standalone",
  transpilePackages: ["@frame/registry-cache", "@frame/shell", "@frame/theme", "@frame/ui"],
  ...(allowedDevOrigins.length > 0 ? { allowedDevOrigins } : {}),
};

export default nextConfig;
