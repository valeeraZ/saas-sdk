import type { NextConfig } from "next";

const allowedDevOrigins = (process.env.SAAS_ALLOWED_DEV_ORIGINS ?? "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

const nextConfig: NextConfig = {
  output: "standalone",
  transpilePackages: ["@saas-platform/registry-cache", "@saas-platform/shell", "@saas-platform/theme", "@saas-platform/ui"],
  ...(allowedDevOrigins.length > 0 ? { allowedDevOrigins } : {}),
};

export default nextConfig;
