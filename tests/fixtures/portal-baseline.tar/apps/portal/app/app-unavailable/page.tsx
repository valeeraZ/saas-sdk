type UnavailablePageProps = Readonly<{
  searchParams: Promise<{ app?: string }>;
}>;

export default async function AppUnavailable({ searchParams }: UnavailablePageProps) {
  const { app } = await searchParams;
  return (
    <div className="flex max-w-4xl flex-col gap-8">
      <SaasPageHeader
        breadcrumbs={[{ href: "/", label: "SAAS" }, { label: "Unavailable" }]}
        description={app ? `${app} is currently inactive.` : "This App is currently inactive."}
        eyebrow="Publication state"
        status="400 · Unavailable"
        title="This App is not published."
      />
      <div><Button asChild><a href="/">Return to SAAS</a></Button></div>
    </div>
  );
}
import { SaasPageHeader } from "@saas-platform/shell/page-header";
import { Button } from "@saas-platform/ui/components/button";
