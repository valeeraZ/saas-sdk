import { FrameShell } from "@frame/shell";
import {
  createInitialFramePreferences,
  FRAME_SIDEBAR_COOKIE,
  FRAME_THEME_COOKIE,
} from "@frame/theme";
import "@frame/ui/globals.css";
import type { Metadata } from "next";
import { cookies, headers } from "next/headers";
import type { ReactNode } from "react";

import { resolvePortalFrameSession } from "../lib/frame-session.ts";

export const metadata: Metadata = {
  title: "FRAME Workspace",
  description: "A unified workspace for FRAME applications",
};

export default async function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  const [cookieStore, requestHeaders] = await Promise.all([cookies(), headers()]);
  const initialPreferences = createInitialFramePreferences(
    cookieStore.get(FRAME_THEME_COOKIE)?.value,
    cookieStore.get(FRAME_SIDEBAR_COOKIE)?.value,
  );
  const session = await resolvePortalFrameSession({ headers: requestHeaders });
  return (
    <html
      lang="en"
      className={initialPreferences.theme === "dark" ? "dark" : undefined}
      data-theme={initialPreferences.theme}
      suppressHydrationWarning
    >
      <body>
        <FrameShell
          canAccessAdmin={session.canAccessAdmin}
          currentAppLabel="FRAME Portal"
          currentAppName="portal"
          initialPreferences={initialPreferences}
          navigation={session.navigation}
          user={session.user}
        >
          {children}
        </FrameShell>
      </body>
    </html>
  );
}
