import { SaasShell } from "@saas-platform/shell";
import {
  createInitialSaasPreferences,
  SAAS_SIDEBAR_COOKIE,
  SAAS_THEME_COOKIE,
} from "@saas-platform/theme";
import "@saas-platform/ui/globals.css";
import type { Metadata } from "next";
import { cookies, headers } from "next/headers";
import type { ReactNode } from "react";

import { resolvePortalSaasSession } from "../lib/saas-session.ts";

export const metadata: Metadata = {
  title: "SAAS Workspace",
  description: "A unified workspace for SAAS applications",
};

export default async function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  const [cookieStore, requestHeaders] = await Promise.all([cookies(), headers()]);
  const initialPreferences = createInitialSaasPreferences(
    cookieStore.get(SAAS_THEME_COOKIE)?.value,
    cookieStore.get(SAAS_SIDEBAR_COOKIE)?.value,
  );
  const session = await resolvePortalSaasSession({ headers: requestHeaders });
  return (
    <html
      lang="en"
      className={initialPreferences.theme === "dark" ? "dark" : undefined}
      data-theme={initialPreferences.theme}
      suppressHydrationWarning
    >
      <body>
        <SaasShell
          canAccessAdmin={session.canAccessAdmin}
          currentAppLabel="SAAS Portal"
          currentAppName="portal"
          initialPreferences={initialPreferences}
          navigation={session.navigation}
          user={session.user}
        >
          {children}
        </SaasShell>
      </body>
    </html>
  );
}
