import { Alert, AlertDescription, AlertTitle } from "@saas-platform/ui/components/alert";
import { LockKeyholeIcon } from "lucide-react";
import { headers } from "next/headers";

import { AdminAuthorizationError, authorizeSaasAdmin } from "../../lib/admin/security.ts";
import { getOnboardingService } from "../../lib/admin/service.ts";
import { AdminDashboard } from "./admin-dashboard.tsx";

export default async function AdminPage() {
  const requestHeaders = await headers();
  const request = new Request("http://saas.internal/admin", {
    headers: requestHeaders,
  });
  try {
    const principal = await authorizeSaasAdmin(request);
    const apps = await getOnboardingService().list(principal.token);
    return <AdminDashboard initialApps={apps} />;
  } catch (error) {
    if (error instanceof AdminAuthorizationError) {
      return (
        <Alert variant="destructive">
          <LockKeyholeIcon />
          <AlertTitle>Admin access required</AlertTitle>
          <AlertDescription>
            This page requires a role configured in SAAS_ADMIN_ROLES.
          </AlertDescription>
        </Alert>
      );
    }
    return (
      <AdminDashboard
        initialApps={[]}
        initialError="Registry Admin data is temporarily unavailable"
      />
    );
  }
}
