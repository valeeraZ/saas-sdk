"use client";

import { FramePageHeader } from "@frame/shell/page-header";
import { Alert, AlertDescription, AlertTitle } from "@frame/ui/components/alert";
import { Badge } from "@frame/ui/components/badge";
import { Button } from "@frame/ui/components/button";
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@frame/ui/components/card";
import {
  Field,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSet,
} from "@frame/ui/components/field";
import { Input } from "@frame/ui/components/input";
import {
  ActivityIcon,
  CircleAlertIcon,
  CircleCheckIcon,
  PlusIcon,
  RefreshCwIcon,
  RocketIcon,
  ShieldCheckIcon,
  Trash2Icon,
} from "lucide-react";
import { useState, useTransition, type FormEvent } from "react";

import type {
  AdminAppView,
  OnboardAppRequest,
} from "../../lib/admin/contracts.ts";

type EditableRole = {
  id: number;
  name: string;
  description: string;
};

type ApiResult = {
  app?: AdminAppView;
  message?: string;
  issues?: string[];
  error?: string;
};

function stateVariant(
  state: AdminAppView["state"],
): "default" | "secondary" | "destructive" | "outline" {
  if (state === "FAILED") return "destructive";
  if (state === "ACTIVE") return "default";
  if (state === "READY") return "secondary";
  return "outline";
}

async function readApiResult(response: Response): Promise<ApiResult> {
  try {
    return (await response.json()) as ApiResult;
  } catch {
    return { error: "invalid_response" };
  }
}

export function AdminDashboard({
  initialApps,
  initialError,
}: Readonly<{
  initialApps: readonly AdminAppView[];
  initialError?: string;
}>) {
  const [apps, setApps] = useState<readonly AdminAppView[]>(initialApps);
  const [roles, setRoles] = useState<EditableRole[]>([
    { id: 1, name: "app-user", description: "Can use this application" },
  ]);
  const [feedback, setFeedback] = useState<string | undefined>(initialError);
  const [pendingAction, setPendingAction] = useState<string | undefined>();
  const [isPending, startTransition] = useTransition();

  function mergeApp(app: AdminAppView): void {
    setApps((current) =>
      [...current.filter((candidate) => candidate.appName !== app.appName), app].sort(
        (left, right) => left.name.localeCompare(right.name),
      ),
    );
  }

  function mutate(
    action: string,
    request: () => Promise<Response>,
    successMessage: string,
  ): void {
    setPendingAction(action);
    setFeedback(undefined);
    startTransition(async () => {
      try {
        const response = await request();
        const result = await readApiResult(response);
        if (result.app) mergeApp(result.app);
        if (!response.ok) {
          setFeedback(
            result.app?.failure?.message ??
              result.message ??
              result.issues?.join("; ") ??
              "The Admin operation did not complete",
          );
          return;
        }
        setFeedback(successMessage);
      } catch {
        setFeedback("Portal Admin is temporarily unavailable");
      } finally {
        setPendingAction(undefined);
      }
    });
  }

  function submitOnboarding(event: FormEvent<HTMLFormElement>): void {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const optional = (name: string): string | undefined => {
      const value = String(data.get(name) ?? "").trim();
      return value.length > 0 ? value : undefined;
    };
    const request: OnboardAppRequest = {
      app: {
        appName: String(data.get("appName") ?? "").trim(),
        name: String(data.get("name") ?? "").trim(),
        description: String(data.get("description") ?? "").trim(),
        logo: String(data.get("logo") ?? "Boxes").trim() as OnboardAppRequest["app"]["logo"],
        basePath: String(data.get("basePath") ?? "").trim(),
        frontendTarget: String(data.get("frontendTarget") ?? "").trim(),
        ...(optional("owner") ? { owner: optional("owner") } : {}),
        ...(optional("healthcheck")
          ? { healthcheck: optional("healthcheck") }
          : {}),
      },
      authorization: {
        roles: roles.map(({ name, description }) => ({
          name: name.trim(),
          description: description.trim(),
        })),
      },
    };
    mutate(
      `onboard:${request.app.appName}`,
      () =>
        fetch("/api/admin/apps/onboard", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(request),
        }),
      `${request.app.name} passed onboarding checks and is ready for activation`,
    );
  }

  return (
    <div className="flex flex-col gap-10">
      <FramePageHeader
        breadcrumbs={[{ href: "/", label: "FRAME" }, { label: "Admin" }]}
        description="Create Registry metadata inactive, configure Auth Service roles, verify runtime contracts, then activate explicitly."
        eyebrow="Control plane"
        status="Phase 5"
        title="Onboard applications without crossing ownership boundaries."
      />

      {feedback ? (
        <Alert>
          <CircleAlertIcon />
          <AlertTitle>Admin update</AlertTitle>
          <AlertDescription>{feedback}</AlertDescription>
        </Alert>
      ) : null}

      <section className="grid gap-5 xl:grid-cols-[minmax(24rem,0.85fr)_minmax(0,1.15fr)]">
        <Card>
          <CardHeader>
            <CardTitle>New application</CardTitle>
            <CardDescription>
              Registry fields and authorization fields are sent to separate systems.
            </CardDescription>
            <CardAction>
              <ShieldCheckIcon />
            </CardAction>
          </CardHeader>
          <CardContent>
            <form id="onboarding-form" onSubmit={submitOnboarding}>
              <FieldGroup>
                <FieldSet>
                  <FieldLegend>Registry metadata and routing</FieldLegend>
                  <FieldGroup>
                    <Field>
                      <FieldLabel htmlFor="appName">Immutable App name</FieldLabel>
                      <Input
                        id="appName"
                        name="appName"
                        pattern="[a-z0-9]+(?:-[a-z0-9]+)*"
                        placeholder="risk-dashboard"
                        required
                      />
                      <FieldDescription>Lowercase kebab-case join key.</FieldDescription>
                    </Field>
                    <Field>
                      <FieldLabel htmlFor="name">Display name</FieldLabel>
                      <Input id="name" name="name" placeholder="Risk Dashboard" required />
                    </Field>
                    <Field>
                      <FieldLabel htmlFor="description">Description</FieldLabel>
                      <Input
                        id="description"
                        maxLength={280}
                        name="description"
                        placeholder="Risk reports and controls"
                        required
                      />
                    </Field>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field>
                        <FieldLabel htmlFor="logo">Approved icon</FieldLabel>
                        <Input
                          id="logo"
                          list="approved-app-logos"
                          name="logo"
                          defaultValue="Boxes"
                          required
                        />
                        <datalist id="approved-app-logos">
                          <option value="Boxes" />
                          <option value="ChartBar" />
                          <option value="CircleGauge" />
                          <option value="Orbit" />
                        </datalist>
                      </Field>
                      <Field>
                        <FieldLabel htmlFor="basePath">Base path</FieldLabel>
                        <Input
                          id="basePath"
                          name="basePath"
                          pattern="/[a-z0-9]+(?:-[a-z0-9]+)*"
                          placeholder="/risk"
                          required
                        />
                      </Field>
                    </div>
                    <Field>
                      <FieldLabel htmlFor="frontendTarget">Server-only frontend target</FieldLabel>
                      <Input
                        id="frontendTarget"
                        name="frontendTarget"
                        placeholder="http://risk-frontend.risk.svc.cluster.local:3000"
                        required
                      />
                      <FieldDescription>
                        Validated against the Registry SSRF allowlist; never enters Navigation.
                      </FieldDescription>
                    </Field>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field>
                        <FieldLabel htmlFor="owner">Owner</FieldLabel>
                        <Input id="owner" name="owner" placeholder="Risk Platform" />
                      </Field>
                      <Field>
                        <FieldLabel htmlFor="healthcheck">Health path</FieldLabel>
                        <Input id="healthcheck" name="healthcheck" placeholder="/api/frame/health" />
                      </Field>
                    </div>
                  </FieldGroup>
                </FieldSet>

                <FieldSet>
                  <FieldLegend>Auth Service role definitions</FieldLegend>
                  <FieldGroup>
                    {roles.map((role, index) => (
                      <Field key={role.id}>
                        <div className="grid gap-3 sm:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)_auto]">
                          <Input
                            aria-label={`Role ${index + 1} name`}
                            value={role.name}
                            onChange={(event) =>
                              setRoles((current) =>
                                current.map((candidate) =>
                                  candidate.id === role.id
                                    ? { ...candidate, name: event.target.value }
                                    : candidate,
                                ),
                              )
                            }
                            placeholder="risk-user"
                            required
                          />
                          <Input
                            aria-label={`Role ${index + 1} description`}
                            value={role.description}
                            onChange={(event) =>
                              setRoles((current) =>
                                current.map((candidate) =>
                                  candidate.id === role.id
                                    ? { ...candidate, description: event.target.value }
                                    : candidate,
                                ),
                              )
                            }
                            placeholder="Can view risk reports"
                            required
                          />
                          <Button
                            aria-label={`Remove role ${index + 1}`}
                            disabled={roles.length === 1}
                            onClick={() =>
                              setRoles((current) =>
                                current.filter((candidate) => candidate.id !== role.id),
                              )
                            }
                            size="icon"
                            type="button"
                            variant="ghost"
                          >
                            <Trash2Icon />
                          </Button>
                        </div>
                      </Field>
                    ))}
                  </FieldGroup>
                  <Button
                    onClick={() =>
                      setRoles((current) => [
                        ...current,
                        {
                          id: Math.max(...current.map(({ id }) => id)) + 1,
                          name: "",
                          description: "",
                        },
                      ])
                    }
                    type="button"
                    variant="outline"
                  >
                    <PlusIcon data-icon="inline-start" />
                    Add role
                  </Button>
                </FieldSet>
              </FieldGroup>
            </form>
          </CardContent>
          <CardFooter className="justify-end">
            <Button disabled={isPending} form="onboarding-form" type="submit">
              <RocketIcon data-icon="inline-start" />
              {pendingAction?.startsWith("onboard:") ? "Onboarding…" : "Run onboarding"}
            </Button>
          </CardFooter>
        </Card>

        <div className="flex flex-col gap-5">
          <div className="flex items-end justify-between gap-4">
            <div>
              <p className="font-mono text-[0.68rem] font-semibold uppercase tracking-[0.18em] text-primary">
                Registry publication
              </p>
              <h2 className="mt-2 text-2xl font-semibold tracking-[-0.035em]">
                Applications
              </h2>
            </div>
            <Badge variant="secondary">{apps.length} total</Badge>
          </div>

          {apps.map((app) => (
            <Card key={app.appName}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {app.active ? <CircleCheckIcon /> : <ActivityIcon />}
                  {app.name}
                </CardTitle>
                <CardDescription>
                  {app.appName} · {app.basePath}
                </CardDescription>
                <CardAction>
                  <Badge variant={stateVariant(app.state)}>{app.state}</Badge>
                </CardAction>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                <p className="text-sm text-muted-foreground">{app.description}</p>
                <div className="flex flex-wrap gap-2">
                  {["REGISTRY_CREATED", "AUTH_CONFIGURED", "READY", "ACTIVE"].map(
                    (state) => (
                      <Badge
                        key={state}
                        variant={app.state === state ? "secondary" : "outline"}
                      >
                        {state}
                      </Badge>
                    ),
                  )}
                </div>
                {app.failure ? (
                  <Alert variant="destructive">
                    <CircleAlertIcon />
                    <AlertTitle>{app.failure.system} step failed</AlertTitle>
                    <AlertDescription>{app.failure.message}</AlertDescription>
                  </Alert>
                ) : null}
              </CardContent>
              {app.state === "FAILED" || app.state === "READY" ? (
                <CardFooter className="justify-end gap-2">
                  {app.state === "FAILED" ? (
                    <Button
                      disabled={isPending}
                      onClick={() =>
                        mutate(
                          `retry:${app.appName}`,
                          () =>
                            fetch(
                              `/api/admin/apps/${encodeURIComponent(app.appName)}/retry`,
                              { method: "POST" },
                            ),
                          `${app.name} resumed from its last completed step`,
                        )
                      }
                      variant="outline"
                    >
                      <RefreshCwIcon data-icon="inline-start" />
                      {pendingAction === `retry:${app.appName}` ? "Retrying…" : "Retry"}
                    </Button>
                  ) : (
                    <Button
                      disabled={isPending}
                      onClick={() =>
                        mutate(
                          `activate:${app.appName}`,
                          () =>
                            fetch(
                              `/api/admin/apps/${encodeURIComponent(app.appName)}/activate`,
                              { method: "POST" },
                            ),
                          `${app.name} is active`,
                        )
                      }
                    >
                      <RocketIcon data-icon="inline-start" />
                      {pendingAction === `activate:${app.appName}`
                        ? "Activating…"
                        : "Activate"}
                    </Button>
                  )}
                </CardFooter>
              ) : null}
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
