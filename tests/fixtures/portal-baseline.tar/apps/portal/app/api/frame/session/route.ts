import { FramePermissionsError } from "@frame/auth";
import { RegistryClientError } from "@frame/registry-cache";
import { NextResponse } from "next/server";

import { resolvePortalFrameSession } from "../../../../lib/frame-session.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request): Promise<NextResponse> {
  try {
    const session = await resolvePortalFrameSession(request);
    return NextResponse.json(session, {
      headers: { "cache-control": "no-store" },
    });
  } catch (error) {
    if (error instanceof FramePermissionsError) {
      const status = error.category === "missing_token" ? 401 : 403;
      return NextResponse.json({ error: "unauthorized" }, { status });
    }
    if (error instanceof RegistryClientError) {
      return NextResponse.json(
        { error: "registry_unavailable" },
        { status: 503, headers: { "retry-after": "3" } },
      );
    }
    console.error("Portal session resolution failed", error);
    return NextResponse.json({ error: "session_unavailable" }, { status: 503 });
  }
}
