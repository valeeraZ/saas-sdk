import { NextResponse } from "next/server";

import {
  getServerIdentityResolver,
  IdentityResolutionError,
} from "../../../../../lib/preferences/identity.ts";
import { getPortalPool } from "../../../../../lib/preferences/pool.ts";
import { PreferencesRepository } from "../../../../../lib/preferences/repository.ts";
import { PreferencesService } from "../../../../../lib/preferences/service.ts";
import {
  parsePreferencesPatch,
  PreferencesValidationError,
} from "../../../../../lib/preferences/validation.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function getPreferencesService(): PreferencesService {
  return new PreferencesService(
    getServerIdentityResolver(),
    new PreferencesRepository(getPortalPool()),
  );
}

function errorResponse(error: unknown): NextResponse {
  if (error instanceof IdentityResolutionError) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  if (error instanceof PreferencesValidationError) {
    return NextResponse.json(
      { error: "invalid_preferences", issues: error.issues },
      { status: 400 },
    );
  }
  console.error("Portal Preferences request failed", error);
  return NextResponse.json({ error: "preferences_unavailable" }, { status: 503 });
}

export async function GET(request: Request): Promise<NextResponse> {
  try {
    const preferences = await getPreferencesService().get(request);
    return NextResponse.json(preferences, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request): Promise<NextResponse> {
  try {
    const contentType = request.headers.get("content-type") ?? "";
    if (!contentType.toLowerCase().startsWith("application/json")) {
      throw new PreferencesValidationError(["content-type: application/json is required"]);
    }
    const patch = parsePreferencesPatch(await request.json());
    const preferences = await getPreferencesService().update(request, patch);
    return NextResponse.json(preferences, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return errorResponse(error);
  }
}
