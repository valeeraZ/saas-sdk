import { NextResponse } from "next/server";

import { adminErrorResponse } from "../../../../../../lib/admin/http.ts";
import {
  authorizeFrameAdmin,
  enforceAdminRateLimit,
  requireSameOrigin,
} from "../../../../../../lib/admin/security.ts";
import { getOnboardingService } from "../../../../../../lib/admin/service.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(
  request: Request,
  context: Readonly<{ params: Promise<{ appName: string }> }>,
): Promise<NextResponse> {
  try {
    requireSameOrigin(request);
    const principal = await authorizeFrameAdmin(request);
    enforceAdminRateLimit(principal.userId, "retry");
    const { appName } = await context.params;
    const app = await getOnboardingService().retry(appName, principal.token);
    return NextResponse.json(
      { app },
      { status: app.state === "FAILED" ? 502 : 200 },
    );
  } catch (error) {
    return adminErrorResponse(error);
  }
}
