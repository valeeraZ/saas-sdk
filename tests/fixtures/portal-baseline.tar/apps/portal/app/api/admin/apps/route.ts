import { NextResponse } from "next/server";

import { adminErrorResponse } from "../../../../lib/admin/http.ts";
import { authorizeFrameAdmin } from "../../../../lib/admin/security.ts";
import { getOnboardingService } from "../../../../lib/admin/service.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request): Promise<NextResponse> {
  try {
    const principal = await authorizeFrameAdmin(request);
    const apps = await getOnboardingService().list(principal.token);
    return NextResponse.json(
      { apps },
      { headers: { "cache-control": "no-store" } },
    );
  } catch (error) {
    return adminErrorResponse(error);
  }
}
