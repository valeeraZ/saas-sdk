import { loadRegistryRuntimeConfig } from "@saas-platform/registry-cache";
import { NextResponse } from "next/server";

import { parseOnboardAppRequest } from "../../../../../lib/admin/contracts.ts";
import { adminErrorResponse } from "../../../../../lib/admin/http.ts";
import {
  authorizeSaasAdmin,
  enforceAdminRateLimit,
  readAdminJsonBody,
  requireSameOrigin,
} from "../../../../../lib/admin/security.ts";
import { getOnboardingService } from "../../../../../lib/admin/service.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<NextResponse> {
  try {
    requireSameOrigin(request);
    const principal = await authorizeSaasAdmin(request);
    enforceAdminRateLimit(principal.userId, "onboard");
    const body = await readAdminJsonBody(request);
    const targetPolicy = loadRegistryRuntimeConfig(process.env).targetPolicy;
    const onboardingRequest = parseOnboardAppRequest(body, targetPolicy);
    const app = await getOnboardingService().onboard(
      onboardingRequest,
      principal.token,
    );
    return NextResponse.json(
      { app },
      { status: app.state === "FAILED" ? 502 : 200 },
    );
  } catch (error) {
    return adminErrorResponse(error);
  }
}
