"use client";

import { SaasPageHeader } from "@saas-platform/shell/page-header";
import { useSaasNavigation } from "@saas-platform/shell/navigation-context";
import { useSaasPreferences } from "@saas-platform/shell/preferences";
import { Badge } from "@saas-platform/ui/components/badge";
import { Button } from "@saas-platform/ui/components/button";
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@saas-platform/ui/components/card";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@saas-platform/ui/components/empty";
import {
  ArrowUpRightIcon,
  BoxesIcon,
  EyeOffIcon,
  NetworkIcon,
  RouteIcon,
} from "lucide-react";

export default function PortalHome() {
  const { preferences } = useSaasPreferences();
  const navigation = useSaasNavigation();
  const hiddenApps = new Set(preferences.hiddenApps);
  const visibleApps = navigation.filter(
    (item) => item.appName !== null && !hiddenApps.has(item.appName),
  );

  return (
    <div className="flex flex-col gap-10">
      <SaasPageHeader
        breadcrumbs={[{ label: "SAAS" }, { label: "Home" }]}
        description="One origin, one navigation model, and a shared operating surface for independently deployed applications."
        eyebrow="Unified workspace"
        status="Phase 5"
        title="Your applications, in one saas."
      />

      <section className="grid gap-3 sm:grid-cols-3" aria-label="Platform status">
        <Card size="sm">
          <CardHeader>
            <CardDescription>Visible applications</CardDescription>
            <CardAction><BoxesIcon /></CardAction>
            <CardTitle className="font-mono text-2xl">{String(visibleApps.length).padStart(2, "0")}</CardTitle>
          </CardHeader>
        </Card>
        <Card size="sm">
          <CardHeader>
            <CardDescription>Public frontend origins</CardDescription>
            <CardAction><RouteIcon /></CardAction>
            <CardTitle className="font-mono text-2xl">01</CardTitle>
          </CardHeader>
        </Card>
        <Card size="sm">
          <CardHeader>
            <CardDescription>Connected clusters</CardDescription>
            <CardAction><NetworkIcon /></CardAction>
            <CardTitle className="font-mono text-2xl">02</CardTitle>
          </CardHeader>
        </Card>
      </section>

      <section className="flex flex-col gap-5" aria-labelledby="applications-heading">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="font-mono text-[0.68rem] font-semibold uppercase tracking-[0.18em] text-primary">
              Navigation
            </p>
            <h2 id="applications-heading" className="mt-2 text-2xl font-semibold tracking-[-0.035em]">
              Available applications
            </h2>
          </div>
          <Button asChild variant="ghost">
            <a href="/settings">Manage visibility</a>
          </Button>
        </div>

        {visibleApps.length > 0 ? (
          <div className="grid gap-4 lg:grid-cols-3">
            {visibleApps.map((app) => {
              return (
                <a className="group block rounded-xl outline-none focus-visible:ring-3 focus-visible:ring-ring/50" href={app.href} key={app.href}>
                  <Card className="h-full transition-transform duration-200 group-hover:-translate-y-1">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        <span className="grid size-10 place-items-center rounded-lg bg-secondary text-secondary-foreground">
                          <BoxesIcon />
                        </span>
                        {app.label}
                      </CardTitle>
                      <CardDescription>{app.description}</CardDescription>
                      <CardAction>
                        <ArrowUpRightIcon />
                      </CardAction>
                    </CardHeader>
                    <CardContent className="mt-auto">
                      <Badge variant="secondary">Authorized App</Badge>
                    </CardContent>
                  </Card>
                </a>
              );
            })}
          </div>
        ) : (
          <Empty className="border">
            <EmptyHeader>
              <EmptyMedia variant="icon"><EyeOffIcon /></EmptyMedia>
              <EmptyTitle>Every App is hidden</EmptyTitle>
              <EmptyDescription>Your direct App URLs still work. Restore an App from Settings.</EmptyDescription>
            </EmptyHeader>
            <EmptyContent>
              <Button asChild><a href="/settings">Open Settings</a></Button>
            </EmptyContent>
          </Empty>
        )}
      </section>
    </div>
  );
}
