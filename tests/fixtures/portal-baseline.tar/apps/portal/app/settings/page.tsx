"use client";

import { FramePageHeader } from "@frame/shell/page-header";
import { useFrameNavigation } from "@frame/shell/navigation-context";
import { useFramePreferences } from "@frame/shell/preferences";
import { Alert, AlertDescription, AlertTitle } from "@frame/ui/components/alert";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@frame/ui/components/card";
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSet,
  FieldTitle,
} from "@frame/ui/components/field";
import { Switch } from "@frame/ui/components/switch";
import { CircleAlertIcon, MonitorCogIcon, MoonIcon, PanelLeftCloseIcon, SunIcon } from "lucide-react";

export default function SettingsPage() {
  const { error, isSaving, preferences, updatePreferences } = useFramePreferences();
  const navigation = useFrameNavigation();
  const appItems = navigation.filter((item) => item.appName !== null);

  return (
    <div className="flex max-w-5xl flex-col gap-10">
      <FramePageHeader
        breadcrumbs={[{ href: "/", label: "FRAME" }, { label: "Settings" }]}
        description="Preferences are synchronized by Portal and follow you across every FRAME application."
        eyebrow="Personal workspace"
        status={isSaving ? "Saving" : "Server-backed"}
        title="Make FRAME feel like yours."
      />

      {error ? (
        <Alert variant="destructive">
          <CircleAlertIcon />
          <AlertTitle>Server synchronization is unavailable</AlertTitle>
          <AlertDescription>{error}. Your last local preference is still active.</AlertDescription>
        </Alert>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(20rem,0.9fr)]">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><MonitorCogIcon /> Appearance</CardTitle>
            <CardDescription>Choose the visual mode used by Portal and every App.</CardDescription>
          </CardHeader>
          <CardContent>
            <FieldGroup>
              <Field orientation="horizontal">
                <FieldContent>
                  <FieldLabel htmlFor="dark-theme">
                    <FieldTitle className="flex items-center gap-2">
                      {preferences.theme === "dark" ? <MoonIcon /> : <SunIcon />}
                      Dark theme
                    </FieldTitle>
                  </FieldLabel>
                  <FieldDescription>Switch between the paper-light and graphite-dark palettes.</FieldDescription>
                </FieldContent>
                <Switch
                  id="dark-theme"
                  checked={preferences.theme === "dark"}
                  onCheckedChange={(checked) =>
                    void updatePreferences({ theme: checked ? "dark" : "light" }).catch(() => undefined)
                  }
                />
              </Field>
              <Field orientation="horizontal">
                <FieldContent>
                  <FieldLabel htmlFor="sidebar-collapsed">
                    <FieldTitle className="flex items-center gap-2"><PanelLeftCloseIcon /> Compact Sidebar</FieldTitle>
                  </FieldLabel>
                  <FieldDescription>Keep navigation collapsed to icons on desktop.</FieldDescription>
                </FieldContent>
                <Switch
                  id="sidebar-collapsed"
                  checked={preferences.sidebarCollapsed}
                  onCheckedChange={(checked) =>
                    void updatePreferences({ sidebarCollapsed: checked }).catch(() => undefined)
                  }
                />
              </Field>
            </FieldGroup>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Application visibility</CardTitle>
            <CardDescription>Hidden Apps leave Home and Sidebar but remain directly accessible.</CardDescription>
          </CardHeader>
          <CardContent>
            <FieldSet>
              <FieldLegend className="sr-only">Visible applications</FieldLegend>
              <FieldGroup>
                {appItems.map((item) => {
                  const appName = item.appName!;
                  const isVisible = !preferences.hiddenApps.includes(appName);
                  return (
                    <Field orientation="horizontal" key={appName}>
                      <FieldContent>
                        <FieldLabel htmlFor={`visible-${appName}`}><FieldTitle>{item.label}</FieldTitle></FieldLabel>
                        <FieldDescription>{item.description}</FieldDescription>
                      </FieldContent>
                      <Switch
                        id={`visible-${appName}`}
                        checked={isVisible}
                        onCheckedChange={(checked) => {
                          const hiddenApps = checked
                            ? preferences.hiddenApps.filter((hidden) => hidden !== appName)
                            : [...preferences.hiddenApps, appName];
                          void updatePreferences({ hiddenApps }).catch(() => undefined);
                        }}
                      />
                    </Field>
                  );
                })}
              </FieldGroup>
            </FieldSet>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
