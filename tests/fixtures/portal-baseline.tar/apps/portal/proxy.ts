import { buildUpstreamUrl } from "@frame/registry-cache";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

import { getPortalRegistryRuntime } from "./lib/registry-runtime.ts";

export function proxy(request: NextRequest): NextResponse {
  const store = getPortalRegistryRuntime().store;
  if (request.nextUrl.pathname === "/api/frame/live") {
    return NextResponse.json(
      { live: true, replica: process.env.HOSTNAME ?? "local" },
      { headers: { "cache-control": "no-store" } },
    );
  }
  if (request.nextUrl.pathname === "/api/frame/proxy-status") {
    const status = store.status();
    const routeTable = store.table;
    return NextResponse.json(
      {
        ...status,
        replica: process.env.HOSTNAME ?? "local",
        routes:
          routeTable?.list().map(({ appName, basePath, active }) => ({
            appName,
            basePath,
            active,
          })) ?? [],
      },
      {
        status: status.ready ? 200 : 503,
        headers: { "cache-control": "no-store" },
      },
    );
  }

  const routeTable = store.table;
  if (!routeTable) {
    return NextResponse.json(
      { ready: false, error: "Registry snapshot is not loaded" },
      {
        status: 503,
        headers: {
          "cache-control": "no-store",
          "retry-after": "3",
          "x-frame-registry-ready": "false",
        },
      },
    );
  }

  const route = routeTable.match(request.nextUrl.pathname);
  if (!route) return NextResponse.next();

  if (!route.active) {
    const unavailableUrl = new URL("/app-unavailable", request.url);
    unavailableUrl.searchParams.set("app", route.appName);
    return NextResponse.rewrite(unavailableUrl, {
      status: 400,
      headers: {
        "x-frame-app": route.appName,
        "x-frame-route-version": String(routeTable.version),
      },
    });
  }

  const response = NextResponse.rewrite(
    buildUpstreamUrl(route, request.nextUrl.pathname, request.nextUrl.search),
  );
  response.headers.set("x-frame-app", route.appName);
  response.headers.set("x-frame-route-version", String(routeTable.version));
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
