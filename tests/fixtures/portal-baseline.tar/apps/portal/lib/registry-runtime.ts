import {
  AtomicRouteStore,
  loadRegistryRuntimeConfig,
  RegistryHttpClient,
  RegistryPoller,
} from "@saas-platform/registry-cache";

type PortalRegistryRuntime = Readonly<{
  store: AtomicRouteStore;
  poller: RegistryPoller;
}>;

type PortalGlobal = typeof globalThis & {
  __saasPortalRegistryRuntime?: PortalRegistryRuntime;
  __saasPortalRegistryInitialization?: Promise<void>;
  __saasPortalRegistryShutdownRegistered?: boolean;
};

const portalGlobal = globalThis as PortalGlobal;

export function getPortalRegistryRuntime(): PortalRegistryRuntime {
  if (!portalGlobal.__saasPortalRegistryRuntime) {
    const config = loadRegistryRuntimeConfig(process.env);
    const store = new AtomicRouteStore(config.targetPolicy);
    const client = new RegistryHttpClient(config.client);
    const poller = new RegistryPoller(client, store, {
      minIntervalMs: config.pollMinMs,
      maxIntervalMs: config.pollMaxMs,
      onError(category) {
        console.error(`[saas-registry] poll failed: ${category}`);
      },
    });
    portalGlobal.__saasPortalRegistryRuntime = Object.freeze({ store, poller });
  }
  return portalGlobal.__saasPortalRegistryRuntime;
}

export function initializePortalRegistry(): Promise<void> {
  if (!portalGlobal.__saasPortalRegistryInitialization) {
    const runtime = getPortalRegistryRuntime();
    portalGlobal.__saasPortalRegistryInitialization = (async () => {
      await runtime.poller.pollOnce();
      runtime.poller.start();
      registerShutdown(runtime);
    })();
  }
  return portalGlobal.__saasPortalRegistryInitialization;
}

function registerShutdown(runtime: PortalRegistryRuntime): void {
  if (portalGlobal.__saasPortalRegistryShutdownRegistered) return;
  portalGlobal.__saasPortalRegistryShutdownRegistered = true;
  const stop = () => runtime.poller.stop();
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
  process.once("beforeExit", stop);
}
