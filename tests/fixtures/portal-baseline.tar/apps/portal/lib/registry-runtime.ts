import {
  AtomicRouteStore,
  loadRegistryRuntimeConfig,
  RegistryHttpClient,
  RegistryPoller,
} from "@frame/registry-cache";

type PortalRegistryRuntime = Readonly<{
  store: AtomicRouteStore;
  poller: RegistryPoller;
}>;

type PortalGlobal = typeof globalThis & {
  __framePortalRegistryRuntime?: PortalRegistryRuntime;
  __framePortalRegistryInitialization?: Promise<void>;
  __framePortalRegistryShutdownRegistered?: boolean;
};

const portalGlobal = globalThis as PortalGlobal;

export function getPortalRegistryRuntime(): PortalRegistryRuntime {
  if (!portalGlobal.__framePortalRegistryRuntime) {
    const config = loadRegistryRuntimeConfig(process.env);
    const store = new AtomicRouteStore(config.targetPolicy);
    const client = new RegistryHttpClient(config.client);
    const poller = new RegistryPoller(client, store, {
      minIntervalMs: config.pollMinMs,
      maxIntervalMs: config.pollMaxMs,
      onError(category) {
        console.error(`[frame-registry] poll failed: ${category}`);
      },
    });
    portalGlobal.__framePortalRegistryRuntime = Object.freeze({ store, poller });
  }
  return portalGlobal.__framePortalRegistryRuntime;
}

export function initializePortalRegistry(): Promise<void> {
  if (!portalGlobal.__framePortalRegistryInitialization) {
    const runtime = getPortalRegistryRuntime();
    portalGlobal.__framePortalRegistryInitialization = (async () => {
      await runtime.poller.pollOnce();
      runtime.poller.start();
      registerShutdown(runtime);
    })();
  }
  return portalGlobal.__framePortalRegistryInitialization;
}

function registerShutdown(runtime: PortalRegistryRuntime): void {
  if (portalGlobal.__framePortalRegistryShutdownRegistered) return;
  portalGlobal.__framePortalRegistryShutdownRegistered = true;
  const stop = () => runtime.poller.stop();
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
  process.once("beforeExit", stop);
}
