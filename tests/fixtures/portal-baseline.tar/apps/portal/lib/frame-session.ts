import { resolveFrameServerSession } from "@frame/auth";
import {
  loadRegistryCatalogConfig,
  RegistryCatalogClient,
} from "@frame/registry-cache";
import { buildFrameNavigation } from "@frame/shell/navigation";
import type { IntegratedFrameSession } from "@frame/shell/integrated-session";

type PortalSessionGlobal = typeof globalThis & {
  __frameRegistryCatalogClient?: RegistryCatalogClient;
};

const portalSessionGlobal = globalThis as PortalSessionGlobal;

function getCatalogClient(): RegistryCatalogClient {
  if (!portalSessionGlobal.__frameRegistryCatalogClient) {
    portalSessionGlobal.__frameRegistryCatalogClient = new RegistryCatalogClient(
      loadRegistryCatalogConfig(process.env),
    );
  }
  return portalSessionGlobal.__frameRegistryCatalogClient;
}

export async function resolvePortalFrameSession(
  request: Readonly<{ headers: Pick<Headers, "get"> }>,
): Promise<IntegratedFrameSession> {
  const sessionPromise = resolveFrameServerSession(request, "integrated");
  const catalogPromise = getCatalogClient().get();
  const [session, catalog] = await Promise.all([sessionPromise, catalogPromise]);
  return Object.freeze({
    mode: "integrated",
    user: session.user,
    navigation: buildFrameNavigation(catalog.apps, session.grants),
    canAccessAdmin: session.canAccessAdmin,
  });
}
