import { resolveSaasServerSession } from "@saas-platform/auth";
import {
  loadRegistryCatalogConfig,
  RegistryCatalogClient,
} from "@saas-platform/registry-cache";
import { buildSaasNavigation } from "@saas-platform/shell/navigation";
import type { IntegratedSaasSession } from "@saas-platform/shell/integrated-session";

type PortalSessionGlobal = typeof globalThis & {
  __saasRegistryCatalogClient?: RegistryCatalogClient;
};

const portalSessionGlobal = globalThis as PortalSessionGlobal;

function getCatalogClient(): RegistryCatalogClient {
  if (!portalSessionGlobal.__saasRegistryCatalogClient) {
    portalSessionGlobal.__saasRegistryCatalogClient = new RegistryCatalogClient(
      loadRegistryCatalogConfig(process.env),
    );
  }
  return portalSessionGlobal.__saasRegistryCatalogClient;
}

export async function resolvePortalSaasSession(
  request: Readonly<{ headers: Pick<Headers, "get"> }>,
): Promise<IntegratedSaasSession> {
  const sessionPromise = resolveSaasServerSession(request, "integrated");
  const catalogPromise = getCatalogClient().get();
  const [session, catalog] = await Promise.all([sessionPromise, catalogPromise]);
  return Object.freeze({
    mode: "integrated",
    user: session.user,
    navigation: buildSaasNavigation(catalog.apps, session.grants),
    canAccessAdmin: session.canAccessAdmin,
  });
}
