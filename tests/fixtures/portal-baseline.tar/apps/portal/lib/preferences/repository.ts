import type { FramePreferences } from "@frame/theme";
import type { Pool, PoolClient, QueryResultRow } from "pg";

import type { PreferencesPatch, UserPreferencesRow } from "./types.ts";

type PoolContract = Pick<Pool, "connect" | "query">;
type Queryable = Pick<PoolClient, "query">;

const SELECT_PREFERENCES = `
  select
    preferences.user_id,
    preferences.theme,
    preferences.sidebar_collapsed,
    coalesce(
      array_agg(app_preferences.app_name order by app_preferences.app_name)
        filter (where app_preferences.hidden = true),
      array[]::text[]
    ) as hidden_apps,
    greatest(preferences.updated_at, coalesce(max(app_preferences.updated_at), preferences.updated_at)) as updated_at
  from frame_user_preferences as preferences
  left join frame_user_app_preferences as app_preferences
    on app_preferences.user_id = preferences.user_id
  where preferences.user_id = $1
  group by preferences.user_id
`;

function toPreferences(row: UserPreferencesRow): FramePreferences {
  return {
    theme: row.theme,
    sidebarCollapsed: row.sidebar_collapsed,
    hiddenApps: row.hidden_apps,
    updatedAt: row.updated_at.toISOString(),
  };
}

async function selectPreferences(queryable: Queryable, userId: string): Promise<FramePreferences> {
  const result = await queryable.query<UserPreferencesRow & QueryResultRow>(SELECT_PREFERENCES, [userId]);
  const row = result.rows[0];
  if (!row) throw new Error("Preference row was not created");
  return toPreferences(row);
}

export class PreferencesRepository {
  readonly pool: PoolContract;

  constructor(pool: PoolContract) {
    this.pool = pool;
  }

  async get(userId: string): Promise<FramePreferences> {
    await this.pool.query(
      `insert into frame_user_preferences (user_id)
       values ($1)
       on conflict (user_id) do nothing`,
      [userId],
    );
    return selectPreferences(this.pool as Queryable, userId);
  }

  async update(userId: string, patch: PreferencesPatch): Promise<FramePreferences> {
    const client = await this.pool.connect();
    try {
      await client.query("begin");
      await client.query("set local statement_timeout = '5s'");
      await client.query(
        `insert into frame_user_preferences (user_id)
         values ($1)
         on conflict (user_id) do nothing`,
        [userId],
      );
      await client.query(
        `update frame_user_preferences
            set theme = coalesce($2::text, theme),
                sidebar_collapsed = coalesce($3::boolean, sidebar_collapsed),
                updated_at = now()
          where user_id = $1`,
        [userId, patch.theme ?? null, patch.sidebarCollapsed ?? null],
      );

      if (patch.hiddenApps !== undefined) {
        await client.query("delete from frame_user_app_preferences where user_id = $1", [userId]);
        if (patch.hiddenApps.length > 0) {
          await client.query(
            `insert into frame_user_app_preferences (user_id, app_name, hidden)
             select $1, app_name, true
               from unnest($2::text[]) as app_name
             on conflict (user_id, app_name)
             do update set hidden = excluded.hidden, updated_at = now()`,
            [userId, patch.hiddenApps],
          );
        }
      }

      const preferences = await selectPreferences(client, userId);
      await client.query("commit");
      return preferences;
    } catch (error) {
      await client.query("rollback").catch(() => undefined);
      throw error;
    } finally {
      client.release();
    }
  }
}
