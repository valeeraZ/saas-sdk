import assert from "node:assert/strict";
import test from "node:test";

import {
  SaasPermissionsClient,
  loadSaasAuthConfig,
} from "@saas-platform/auth";

import {
  AuthServiceIdentityResolver,
  IdentityResolutionError,
} from "./identity.ts";

test("resolves only the stable Auth Service user ID", async () => {
  let observedAuthorization: string | null = null;
  const client = new SaasPermissionsClient(
    loadSaasAuthConfig({ SAAS_DSP_TOKEN_COOKIE: "dsp-session" }),
    async (_input, init) => {
      observedAuthorization = new Headers(init?.headers).get("authorization");
      return Response.json({
        display_name: "Trusted User",
        employee_id: "stable-auth-user",
      });
    },
  );
  const resolver = new AuthServiceIdentityResolver(client);
  const request = new Request("http://saas.test/api/saas/me/preferences", {
    headers: {
      cookie: "dsp-session=trusted-token",
      "x-user-id": "attacker",
    },
  });

  assert.equal(await resolver.resolveUserId(request), "stable-auth-user");
  assert.equal(observedAuthorization, "Bearer trusted-token");
});

test("fails closed when the trusted current-user call is unauthorized", async () => {
  const client = new SaasPermissionsClient(
    loadSaasAuthConfig({ SAAS_DSP_TOKEN_COOKIE: "dsp-session" }),
    async () => new Response(null, { status: 401 }),
  );
  const resolver = new AuthServiceIdentityResolver(client);

  await assert.rejects(
    () =>
      resolver.resolveUserId(
        new Request("http://saas.test", {
          headers: { cookie: "dsp-session=expired" },
        }),
      ),
    IdentityResolutionError,
  );
});

test("fails closed when no DSP token Cookie is present", async () => {
  const resolver = new AuthServiceIdentityResolver(
    new SaasPermissionsClient(
      loadSaasAuthConfig({ SAAS_DSP_TOKEN_COOKIE: "dsp-session" }),
      async () => {
        throw new Error("fetch must not be reached");
      },
    ),
  );
  await assert.rejects(
    () => resolver.resolveUserId(new Request("http://saas.test")),
    IdentityResolutionError,
  );
});
