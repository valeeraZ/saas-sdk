import assert from "node:assert/strict";
import { resolve } from "node:path";
import test from "node:test";

import { Pool } from "pg";

import { runPortalMigrations } from "./migration-runner.ts";
import { PreferencesRepository } from "./repository.ts";

const connectionString = process.env.PORTAL_DATABASE_URL;

test(
  "runs clean and repeat migrations, persists preferences, and rolls back failed updates",
  { skip: connectionString ? false : "PORTAL_DATABASE_URL is not configured" },
  async (context) => {
    const schema = `saas_preferences_test_${process.pid}`;
    const adminPool = new Pool({ connectionString, max: 1 });
    await adminPool.query(`create schema ${schema}`);

    const pool = new Pool({
      connectionString,
      max: 2,
      options: `-c search_path=${schema}`,
    });
    context.after(async () => {
      await pool.end();
      await adminPool.query(`drop schema ${schema} cascade`);
      await adminPool.end();
    });

    const migrationsDirectory = resolve(import.meta.dirname, "../../migrations");
    await runPortalMigrations(pool, migrationsDirectory);
    await runPortalMigrations(pool, migrationsDirectory);

    const repository = new PreferencesRepository(pool);
    const defaults = await repository.get("integration-user");
    assert.deepEqual({ ...defaults, updatedAt: null }, {
      theme: "light",
      sidebarCollapsed: false,
      hiddenApps: [],
      updatedAt: null,
    });
    assert.match(defaults.updatedAt ?? "", /^\d{4}-\d{2}-\d{2}T/);

    const updated = await repository.update("integration-user", {
      theme: "dark",
      sidebarCollapsed: true,
      hiddenApps: ["local-beta", "remote-gamma"],
    });
    assert.equal(updated.theme, "dark");
    assert.equal(updated.sidebarCollapsed, true);
    assert.deepEqual(updated.hiddenApps, ["local-beta", "remote-gamma"]);

    await assert.rejects(() =>
      repository.update("integration-user", { theme: "invalid" as "dark" }),
    );
    const afterRollback = await repository.get("integration-user");
    assert.equal(afterRollback.theme, "dark");
    assert.deepEqual(afterRollback.hiddenApps, ["local-beta", "remote-gamma"]);
  },
);
