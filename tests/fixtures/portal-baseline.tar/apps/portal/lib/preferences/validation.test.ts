import assert from "node:assert/strict";
import test from "node:test";

import { parsePreferencesPatch, PreferencesValidationError } from "./validation.ts";

test("normalizes valid preference patches", () => {
  assert.deepEqual(
    parsePreferencesPatch({ theme: "dark", hiddenApps: ["local-beta", "local-beta", "local-alpha"] }),
    { theme: "dark", hiddenApps: ["local-alpha", "local-beta"] },
  );
});

test("rejects empty, unknown, and malformed preference fields", () => {
  for (const value of [
    {},
    { userId: "attacker" },
    { theme: "system" },
    { hiddenApps: ["Not Valid"] },
  ]) {
    assert.throws(() => parsePreferencesPatch(value), PreferencesValidationError);
  }
});
