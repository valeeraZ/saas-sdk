import type { FramePreferences } from "@frame/theme";

import type { ServerIdentityResolver } from "./identity.ts";
import type { PreferencesRepository } from "./repository.ts";
import type { PreferencesPatch } from "./types.ts";

type PreferencesRepositoryContract = Pick<PreferencesRepository, "get" | "update">;

export class PreferencesService {
  readonly identityResolver: ServerIdentityResolver;
  readonly repository: PreferencesRepositoryContract;

  constructor(
    identityResolver: ServerIdentityResolver,
    repository: PreferencesRepositoryContract,
  ) {
    this.identityResolver = identityResolver;
    this.repository = repository;
  }

  async get(request: Request): Promise<FramePreferences> {
    const userId = await this.identityResolver.resolveUserId(request);
    return this.repository.get(userId);
  }

  async update(request: Request, patch: PreferencesPatch): Promise<FramePreferences> {
    const userId = await this.identityResolver.resolveUserId(request);
    return this.repository.update(userId, patch);
  }
}
