import { z } from "zod";

import type { PreferencesPatch } from "./types.ts";

const appNameSchema = z
  .string()
  .min(1)
  .max(100)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "App names must use lowercase kebab-case");

const preferencesPatchSchema = z
  .object({
    theme: z.enum(["light", "dark"]).optional(),
    sidebarCollapsed: z.boolean().optional(),
    hiddenApps: z.array(appNameSchema).max(256).optional(),
  })
  .strict()
  .refine(
    (patch) =>
      patch.theme !== undefined ||
      patch.sidebarCollapsed !== undefined ||
      patch.hiddenApps !== undefined,
    { message: "At least one preference must be supplied" },
  );

export class PreferencesValidationError extends Error {
  readonly issues: readonly string[];

  constructor(issues: readonly string[]) {
    super("Preferences payload is invalid");
    this.name = "PreferencesValidationError";
    this.issues = issues;
  }
}

export function parsePreferencesPatch(value: unknown): PreferencesPatch {
  const result = preferencesPatchSchema.safeParse(value);
  if (!result.success) {
    throw new PreferencesValidationError(
      result.error.issues.map((issue) => `${issue.path.join(".") || "body"}: ${issue.message}`),
    );
  }
  return {
    ...result.data,
    hiddenApps: result.data.hiddenApps ? [...new Set(result.data.hiddenApps)].sort() : undefined,
  };
}
