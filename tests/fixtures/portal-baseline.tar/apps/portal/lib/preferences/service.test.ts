import assert from "node:assert/strict";
import test from "node:test";

import type { FramePreferences } from "@frame/theme";

import type { ServerIdentityResolver } from "./identity.ts";
import { PreferencesService } from "./service.ts";

const preferences: FramePreferences = {
  theme: "light",
  sidebarCollapsed: false,
  hiddenApps: [],
  updatedAt: "2026-07-22T00:00:00.000Z",
};

test("resolves trusted identity before repository reads and writes", async () => {
  const calls: string[] = [];
  const identity: ServerIdentityResolver = {
    async resolveUserId() {
      calls.push("identity");
      return "stable-auth-user";
    },
  };
  const repository = {
    async get(userId: string) {
      calls.push(`get:${userId}`);
      return preferences;
    },
    async update(userId: string) {
      calls.push(`update:${userId}`);
      return preferences;
    },
  };
  const service = new PreferencesService(identity, repository);
  const request = new Request("http://frame.test/api/frame/me/preferences");
  await service.get(request);
  await service.update(request, { theme: "dark" });
  assert.deepEqual(calls, ["identity", "get:stable-auth-user", "identity", "update:stable-auth-user"]);
});

test("never reaches the repository when trusted identity resolution fails", async () => {
  const identity: ServerIdentityResolver = {
    async resolveUserId() {
      throw new Error("unauthorized");
    },
  };
  let repositoryCalled = false;
  const service = new PreferencesService(identity, {
    async get() {
      repositoryCalled = true;
      return preferences;
    },
    async update() {
      repositoryCalled = true;
      return preferences;
    },
  });
  await assert.rejects(() => service.get(new Request("http://frame.test")));
  assert.equal(repositoryCalled, false);
});
