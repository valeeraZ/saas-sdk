import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import { resolve } from "node:path";

import type { Pool } from "pg";

const MIGRATION_FILE_PATTERN = /^\d{4}_[a-z0-9_]+\.sql$/;

export async function runPortalMigrations(pool: Pool, migrationsDirectory: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query("select pg_advisory_lock(hashtext($1))", ["frame_portal_migrations"]);
    await client.query(`
      create table if not exists schema_migrations (
        version text primary key,
        checksum text not null,
        applied_at timestamptz not null default now()
      )
    `);

    const files = (await readdir(migrationsDirectory))
      .filter((file) => MIGRATION_FILE_PATTERN.test(file))
      .sort();

    for (const file of files) {
      const sql = await readFile(resolve(migrationsDirectory, file), "utf8");
      const checksum = createHash("sha256").update(sql).digest("hex");
      const applied = await client.query<{ checksum: string }>(
        "select checksum from schema_migrations where version = $1",
        [file],
      );
      if (applied.rows[0]) {
        if (applied.rows[0].checksum !== checksum) {
          throw new Error(`Applied migration ${file} has a different checksum`);
        }
        continue;
      }

      await client.query("begin");
      try {
        await client.query("set local statement_timeout = '30s'");
        await client.query(sql);
        await client.query(
          "insert into schema_migrations (version, checksum) values ($1, $2)",
          [file, checksum],
        );
        await client.query("commit");
      } catch (error) {
        await client.query("rollback").catch(() => undefined);
        throw error;
      }
    }
  } finally {
    await client
      .query("select pg_advisory_unlock(hashtext($1))", ["frame_portal_migrations"])
      .catch(() => undefined);
    client.release();
  }
}
