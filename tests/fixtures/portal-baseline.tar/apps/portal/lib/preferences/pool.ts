import { Pool } from "pg";

const globalForPortalPool = globalThis as typeof globalThis & {
  __framePortalPool?: Pool;
};

function integerEnvironmentValue(name: string, fallback: number, min: number, max: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const parsed = Number.parseInt(raw, 10);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new Error(`${name} must be an integer between ${min} and ${max}`);
  }
  return parsed;
}

export function getPortalPool(): Pool {
  if (globalForPortalPool.__framePortalPool) return globalForPortalPool.__framePortalPool;
  const connectionString = process.env.PORTAL_DATABASE_URL;
  if (!connectionString) throw new Error("PORTAL_DATABASE_URL is required");

  const pool = new Pool({
    connectionString,
    max: integerEnvironmentValue("PORTAL_DATABASE_POOL_MAX", 5, 1, 20),
    idleTimeoutMillis: integerEnvironmentValue("PORTAL_DATABASE_IDLE_TIMEOUT_MS", 30_000, 1_000, 300_000),
    connectionTimeoutMillis: integerEnvironmentValue(
      "PORTAL_DATABASE_CONNECTION_TIMEOUT_MS",
      5_000,
      250,
      30_000,
    ),
    application_name: "frame-portal",
  });
  pool.on("error", (error) => {
    console.error("Unexpected idle Portal PostgreSQL client error", error);
  });
  globalForPortalPool.__framePortalPool = pool;
  return pool;
}
