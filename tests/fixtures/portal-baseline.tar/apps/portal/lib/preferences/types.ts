import type { FramePreferences, FrameTheme } from "@frame/theme";

export type PreferencesPatch = Readonly<{
  theme?: FrameTheme;
  sidebarCollapsed?: boolean;
  hiddenApps?: readonly string[];
}>;

export type UserPreferencesRow = Readonly<{
  user_id: string;
  theme: FrameTheme;
  sidebar_collapsed: boolean;
  hidden_apps: string[];
  updated_at: Date;
}>;

export type UserPreferences = FramePreferences;
