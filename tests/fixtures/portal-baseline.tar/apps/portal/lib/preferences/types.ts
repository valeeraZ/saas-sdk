import type { SaasPreferences, SaasTheme } from "@saas-platform/theme";

export type PreferencesPatch = Readonly<{
  theme?: SaasTheme;
  sidebarCollapsed?: boolean;
  hiddenApps?: readonly string[];
}>;

export type UserPreferencesRow = Readonly<{
  user_id: string;
  theme: SaasTheme;
  sidebar_collapsed: boolean;
  hidden_apps: string[];
  updated_at: Date;
}>;

export type UserPreferences = SaasPreferences;
