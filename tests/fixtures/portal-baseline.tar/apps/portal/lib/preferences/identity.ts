import {
  FramePermissionsClient,
  FramePermissionsError,
} from "@frame/auth";

export interface ServerIdentityResolver {
  resolveUserId(request: Request): Promise<string>;
}

export class IdentityResolutionError extends Error {
  constructor(message = "A trusted user identity is unavailable") {
    super(message);
    this.name = "IdentityResolutionError";
  }
}

export class AuthServiceIdentityResolver implements ServerIdentityResolver {
  readonly permissionsClient: FramePermissionsClient;

  constructor(permissionsClient = new FramePermissionsClient()) {
    this.permissionsClient = permissionsClient;
  }

  async resolveUserId(request: Request): Promise<string> {
    try {
      const currentUser = await this.permissionsClient.getCurrentUser(request);
      return currentUser.id;
    } catch (error) {
      if (error instanceof FramePermissionsError) {
        throw new IdentityResolutionError();
      }
      throw error;
    }
  }
}

export function getServerIdentityResolver(): ServerIdentityResolver {
  return new AuthServiceIdentityResolver();
}
