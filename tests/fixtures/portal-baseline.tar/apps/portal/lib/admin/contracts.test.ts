import assert from "node:assert/strict";
import test from "node:test";

import { parseOnboardAppRequest } from "./contracts.ts";

const policy = {
  allowedHosts: ["localhost", ".svc.cluster.local"],
  allowHttp: true,
} as const;

const request = {
  app: {
    appName: "risk-dashboard",
    name: "Risk Dashboard",
    description: "Risk reports",
    logo: "ChartBar",
    basePath: "/risk",
    frontendTarget: "http://risk.risk.svc.cluster.local:3000",
  },
  authorization: {
    roles: [{ name: "risk-user", description: "Can view risk reports" }],
  },
};

test("separates Registry and Auth fields in onboarding input", () => {
  const parsed = parseOnboardAppRequest(request, policy);
  assert.equal(parsed.app.frontendTarget, "http://risk.risk.svc.cluster.local:3000");
  assert.deepEqual(parsed.authorization.roles.map(({ name }) => name), ["risk-user"]);
});

test("rejects publication state, unsafe targets, and duplicate roles", () => {
  assert.throws(() =>
    parseOnboardAppRequest(
      { ...request, app: { ...request.app, active: true } },
      policy,
    ),
  );
  assert.throws(() =>
    parseOnboardAppRequest(
      {
        ...request,
        app: { ...request.app, frontendTarget: "http://169.254.169.254/latest" },
      },
      policy,
    ),
  );
  assert.throws(() =>
    parseOnboardAppRequest(
      {
        ...request,
        authorization: {
          roles: [
            request.authorization.roles[0],
            request.authorization.roles[0],
          ],
        },
      },
      policy,
    ),
  );
});
