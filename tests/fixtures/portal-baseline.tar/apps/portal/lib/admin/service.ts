import { createHash, randomUUID } from "node:crypto";

import type {
  AdminAppView,
  CompletedOnboardingState,
  OnboardAppRequest,
  OnboardingFailure,
  OnboardingState,
} from "./contracts.ts";
import {
  AuthAdminClient,
  type AuthAdminPort,
  DownstreamAdminError,
  RegistryAdminClient,
  type RegistryAdminApp,
  type RegistryAdminPort,
} from "./clients.ts";

type WorkflowRecord = {
  request: OnboardAppRequest;
  requestDigest: string;
  idempotencyKey: string;
  state: OnboardingState;
  lastCompletedState: CompletedOnboardingState;
  active: boolean;
  failure?: OnboardingFailure;
  updatedAt: string;
};

export class OnboardingConflictError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OnboardingConflictError";
  }
}

export class OnboardingNotReadyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OnboardingNotReadyError";
  }
}

export class OnboardingNotFoundError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OnboardingNotFoundError";
  }
}

function digestRequest(request: OnboardAppRequest): string {
  return createHash("sha256").update(JSON.stringify(request)).digest("hex");
}

function viewFromRecord(record: WorkflowRecord): AdminAppView {
  return Object.freeze({
    appName: record.request.app.appName,
    name: record.request.app.name,
    description: record.request.app.description,
    logo: record.request.app.logo,
    basePath: record.request.app.basePath,
    active: record.active,
    state: record.state,
    lastCompletedState: record.lastCompletedState,
    ...(record.failure ? { failure: record.failure } : {}),
    updatedAt: record.updatedAt,
  });
}

function viewFromRegistryApp(app: RegistryAdminApp, now: string): AdminAppView {
  return Object.freeze({
    appName: app.appName,
    name: app.name,
    description: app.description,
    logo: app.logo,
    basePath: app.basePath,
    active: app.active,
    state: app.active ? "ACTIVE" : "REGISTRY_CREATED",
    lastCompletedState: "REGISTRY_CREATED",
    updatedAt: now,
  });
}

export class OnboardingService {
  readonly #registry: RegistryAdminPort;
  readonly #auth: AuthAdminPort;
  readonly #records = new Map<string, WorkflowRecord>();
  readonly #inFlight = new Map<string, Promise<AdminAppView>>();
  readonly #now: () => Date;
  readonly #uuid: () => string;

  constructor(
    registry: RegistryAdminPort,
    auth: AuthAdminPort,
    options?: Readonly<{ now?: () => Date; uuid?: () => string }>,
  ) {
    this.#registry = registry;
    this.#auth = auth;
    this.#now = options?.now ?? (() => new Date());
    this.#uuid = options?.uuid ?? randomUUID;
  }

  async onboard(request: OnboardAppRequest, token: string): Promise<AdminAppView> {
    const appName = request.app.appName;
    const digest = digestRequest(request);
    const existing = this.#records.get(appName);
    if (existing && existing.requestDigest !== digest) {
      throw new OnboardingConflictError(
        `${appName} already has an onboarding request with immutable fields`,
      );
    }
    const pending = this.#inFlight.get(appName);
    if (pending) return await pending;

    const record =
      existing ??
      ({
        request,
        requestDigest: digest,
        idempotencyKey: this.#uuid(),
        state: "DRAFT",
        lastCompletedState: "DRAFT",
        active: false,
        updatedAt: this.#now().toISOString(),
      } satisfies WorkflowRecord);
    this.#records.set(appName, record);

    if (record.state === "READY" || record.state === "ACTIVE") {
      return viewFromRecord(record);
    }
    const operation = this.#resume(record, token);
    this.#inFlight.set(appName, operation);
    try {
      return await operation;
    } finally {
      this.#inFlight.delete(appName);
    }
  }

  async retry(appName: string, token: string): Promise<AdminAppView> {
    const record = this.#records.get(appName);
    if (!record) throw new OnboardingNotFoundError(`${appName} was not onboarded by Portal`);
    return await this.onboard(record.request, token);
  }

  async activate(appName: string, token: string): Promise<AdminAppView> {
    const record = this.#records.get(appName);
    if (!record) throw new OnboardingNotFoundError(`${appName} was not onboarded by Portal`);
    if (record.state === "ACTIVE") return viewFromRecord(record);
    if (record.state !== "READY") {
      throw new OnboardingNotReadyError(`${appName} cannot activate before READY`);
    }
    const app = await this.#registry.activateApp(
      appName,
      token,
      record.idempotencyKey,
    );
    if (!app.active) {
      throw new DownstreamAdminError(
        "registry",
        "Registry did not confirm App activation",
      );
    }
    record.active = true;
    record.state = "ACTIVE";
    record.failure = undefined;
    record.updatedAt = this.#now().toISOString();
    return viewFromRecord(record);
  }

  async list(token: string): Promise<readonly AdminAppView[]> {
    const apps = await this.#registry.listApps(token);
    const now = this.#now().toISOString();
    const views = new Map(
      apps.map((app) => {
        const record = this.#records.get(app.appName);
        if (record) {
          record.active = app.active;
          if (app.active) record.state = "ACTIVE";
          return [app.appName, viewFromRecord(record)] as const;
        }
        return [app.appName, viewFromRegistryApp(app, now)] as const;
      }),
    );
    for (const record of this.#records.values()) {
      if (!views.has(record.request.app.appName)) {
        views.set(record.request.app.appName, viewFromRecord(record));
      }
    }
    return Object.freeze(
      [...views.values()].sort((left, right) => left.name.localeCompare(right.name)),
    );
  }

  async #resume(record: WorkflowRecord, token: string): Promise<AdminAppView> {
    let currentSystem: OnboardingFailure["system"] = "registry";
    try {
      if (record.lastCompletedState === "DRAFT") {
        currentSystem = "registry";
        const app = await this.#registry.createApp(
          record.request.app,
          token,
          record.idempotencyKey,
        );
        if (app.appName !== record.request.app.appName || app.active) {
          throw new OnboardingNotReadyError(
            "Registry must create the requested App inactive",
          );
        }
        this.#complete(record, "REGISTRY_CREATED");
      }

      if (record.lastCompletedState === "REGISTRY_CREATED") {
        currentSystem = "auth";
        await this.#auth.putRoles(
          record.request.app.appName,
          record.request.authorization.roles,
          token,
          record.idempotencyKey,
        );
        this.#complete(record, "AUTH_CONFIGURED");
      }

      if (record.lastCompletedState === "AUTH_CONFIGURED") {
        currentSystem = "validation";
        const runtime = await this.#registry.getRuntime(
          record.request.app.appName,
          token,
        );
        if (!runtime.healthy || !runtime.shellCompatible || !runtime.staticResources) {
          throw new OnboardingNotReadyError(
            "Runtime health, Shell, and static-resource checks must all pass",
          );
        }
        this.#complete(record, "READY");
      }
      return viewFromRecord(record);
    } catch (error) {
      const system =
        error instanceof DownstreamAdminError ? error.system : currentSystem;
      record.state = "FAILED";
      record.active = false;
      record.failure = Object.freeze({
        system,
        message:
          error instanceof OnboardingNotReadyError
            ? error.message
            : `${system} onboarding step failed`,
      });
      record.updatedAt = this.#now().toISOString();
      return viewFromRecord(record);
    }
  }

  #complete(record: WorkflowRecord, state: CompletedOnboardingState): void {
    record.lastCompletedState = state;
    record.state = state;
    record.failure = undefined;
    record.updatedAt = this.#now().toISOString();
  }
}

type OnboardingGlobal = typeof globalThis & {
  __saasOnboardingService?: OnboardingService;
};

const onboardingGlobal = globalThis as OnboardingGlobal;

export function getOnboardingService(): OnboardingService {
  if (!onboardingGlobal.__saasOnboardingService) {
    onboardingGlobal.__saasOnboardingService = new OnboardingService(
      new RegistryAdminClient(),
      new AuthAdminClient(),
    );
  }
  return onboardingGlobal.__saasOnboardingService;
}
