import assert from "node:assert/strict";
import test from "node:test";

import type {
  AuthAdminPort,
  RegistryAdminApp,
  RegistryAdminPort,
} from "./clients.ts";
import type { OnboardAppRequest } from "./contracts.ts";
import {
  OnboardingConflictError,
  OnboardingNotReadyError,
  OnboardingService,
} from "./service.ts";

const request: OnboardAppRequest = {
  app: {
    appName: "risk-dashboard",
    name: "Risk Dashboard",
    description: "Risk reports",
    logo: "ChartBar",
    basePath: "/risk",
    frontendTarget: "https://risk.company.net",
  },
  authorization: {
    roles: [{ name: "risk-user", description: "Can view risk reports" }],
  },
};

function registryApp(active = false): RegistryAdminApp {
  return { ...request.app, active };
}

test("resumes after Auth failure without duplicating the Registry App", async () => {
  let registryCreates = 0;
  let authCalls = 0;
  const registry: RegistryAdminPort = {
    async createApp() {
      registryCreates += 1;
      return registryApp();
    },
    async listApps() {
      return [registryApp()];
    },
    async activateApp() {
      return registryApp(true);
    },
    async getRuntime() {
      return {
        appName: request.app.appName,
        healthy: true,
        shellCompatible: true,
        staticResources: true,
        checkedAt: new Date().toISOString(),
      };
    },
  };
  const auth: AuthAdminPort = {
    async putRoles() {
      authCalls += 1;
      if (authCalls === 1) throw new Error("simulated timeout after commit");
    },
  };
  const service = new OnboardingService(registry, auth, {
    uuid: () => "logical-request-1",
  });

  const failed = await service.onboard(request, "token");
  assert.equal(failed.state, "FAILED");
  assert.equal(failed.lastCompletedState, "REGISTRY_CREATED");

  const ready = await service.retry(request.app.appName, "token");
  assert.equal(ready.state, "READY");
  assert.equal(registryCreates, 1);
  assert.equal(authCalls, 2);

  const active = await service.activate(request.app.appName, "token");
  assert.equal(active.state, "ACTIVE");
  assert.equal(active.active, true);
});

test("deduplicates concurrent submissions and rejects immutable changes", async () => {
  let registryCreates = 0;
  const registry: RegistryAdminPort = {
    async createApp() {
      registryCreates += 1;
      await Promise.resolve();
      return registryApp();
    },
    async listApps() {
      return [];
    },
    async activateApp() {
      return registryApp(true);
    },
    async getRuntime() {
      return {
        appName: request.app.appName,
        healthy: true,
        shellCompatible: true,
        staticResources: true,
        checkedAt: new Date().toISOString(),
      };
    },
  };
  const auth: AuthAdminPort = { async putRoles() {} };
  const service = new OnboardingService(registry, auth);

  const [left, right] = await Promise.all([
    service.onboard(request, "token"),
    service.onboard(request, "token"),
  ]);
  assert.equal(left.state, "READY");
  assert.equal(right.state, "READY");
  assert.equal(registryCreates, 1);
  await assert.rejects(
    () =>
      service.onboard(
        { ...request, app: { ...request.app, basePath: "/other" } },
        "token",
      ),
    OnboardingConflictError,
  );
});

test("prohibits activation before all checks pass", async () => {
  const registry: RegistryAdminPort = {
    async createApp() {
      return registryApp();
    },
    async listApps() {
      return [];
    },
    async activateApp() {
      throw new Error("activation must not be called");
    },
    async getRuntime() {
      return {
        appName: request.app.appName,
        healthy: false,
        shellCompatible: true,
        staticResources: true,
        checkedAt: new Date().toISOString(),
      };
    },
  };
  const service = new OnboardingService(registry, { async putRoles() {} });
  assert.equal((await service.onboard(request, "token")).state, "FAILED");
  await assert.rejects(
    () => service.activate(request.app.appName, "token"),
    OnboardingNotReadyError,
  );
});
