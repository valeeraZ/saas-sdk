import { NextResponse } from "next/server";

import { DownstreamAdminError } from "./clients.ts";
import { OnboardingValidationError } from "./contracts.ts";
import {
  AdminAuthorizationError,
  AdminRequestError,
} from "./security.ts";
import {
  OnboardingConflictError,
  OnboardingNotFoundError,
  OnboardingNotReadyError,
} from "./service.ts";

export function adminErrorResponse(error: unknown): NextResponse {
  if (error instanceof AdminAuthorizationError) {
    return NextResponse.json(
      { error: error.status === 401 ? "unauthorized" : "forbidden" },
      { status: error.status },
    );
  }
  if (error instanceof AdminRequestError) {
    return NextResponse.json(
      { error: "invalid_admin_request", message: error.message },
      {
        status: error.status,
        ...(error.status === 429
          ? { headers: { "retry-after": "60" } }
          : {}),
      },
    );
  }
  if (error instanceof OnboardingValidationError) {
    return NextResponse.json(
      { error: "invalid_onboarding_request", issues: error.issues },
      { status: 400 },
    );
  }
  if (error instanceof OnboardingConflictError) {
    return NextResponse.json(
      { error: "onboarding_conflict", message: error.message },
      { status: 409 },
    );
  }
  if (error instanceof OnboardingNotReadyError) {
    return NextResponse.json(
      { error: "app_not_ready", message: error.message },
      { status: 409 },
    );
  }
  if (error instanceof OnboardingNotFoundError) {
    return NextResponse.json(
      { error: "onboarding_not_found", message: error.message },
      { status: 404 },
    );
  }
  if (error instanceof DownstreamAdminError) {
    return NextResponse.json(
      { error: `${error.system}_unavailable` },
      { status: 503, headers: { "retry-after": "3" } },
    );
  }
  console.error("Portal Admin request failed", error);
  return NextResponse.json({ error: "admin_unavailable" }, { status: 503 });
}
