import assert from "node:assert/strict";
import test from "node:test";

import { AdminAuthorizationError, requireSameOrigin } from "./security.ts";

test("accepts the external Host origin when Next normalizes request.url internally", () => {
  assert.doesNotThrow(() =>
    requireSameOrigin(
      new Request("http://localhost:3300/api/admin/apps/onboard", {
        headers: {
          host: "192.168.31.19:3300",
          origin: "http://192.168.31.19:3300",
        },
      }),
    ),
  );
});

test("rejects missing and cross-site Admin mutation origins", () => {
  assert.throws(
    () =>
      requireSameOrigin(
        new Request("https://frame.example/api/admin/apps/onboard", {
          headers: {
            host: "frame.example",
            origin: "https://attacker.example",
          },
        }),
      ),
    AdminAuthorizationError,
  );
  assert.throws(
    () =>
      requireSameOrigin(
        new Request("https://frame.example/api/admin/apps/onboard", {
          headers: { host: "frame.example" },
        }),
      ),
    AdminAuthorizationError,
  );
});
