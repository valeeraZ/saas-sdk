import type { TargetPolicy } from "@saas-platform/registry-cache";
import { validateFrontendTarget } from "@saas-platform/registry-cache";

export const APPROVED_APP_LOGOS = [
  "Boxes",
  "ChartBar",
  "CircleGauge",
  "Orbit",
] as const;

export type ApprovedAppLogo = (typeof APPROVED_APP_LOGOS)[number];

export type RegistryAppInput = Readonly<{
  appName: string;
  name: string;
  description: string;
  logo: ApprovedAppLogo;
  basePath: string;
  frontendTarget: string;
  owner?: string;
  healthcheck?: string;
}>;

export type AppRoleDefinition = Readonly<{
  name: string;
  description: string;
}>;

export type OnboardAppRequest = Readonly<{
  app: RegistryAppInput;
  authorization: Readonly<{
    roles: readonly AppRoleDefinition[];
  }>;
}>;

export type OnboardingState =
  | "DRAFT"
  | "REGISTRY_CREATED"
  | "AUTH_CONFIGURED"
  | "READY"
  | "ACTIVE"
  | "FAILED";

export type CompletedOnboardingState = Exclude<OnboardingState, "FAILED" | "ACTIVE">;

export type OnboardingFailure = Readonly<{
  system: "registry" | "auth" | "validation";
  message: string;
}>;

export type AdminAppView = Readonly<{
  appName: string;
  name: string;
  description: string;
  logo: ApprovedAppLogo;
  basePath: string;
  active: boolean;
  state: OnboardingState;
  lastCompletedState: CompletedOnboardingState;
  failure?: OnboardingFailure;
  updatedAt: string;
}>;

export class OnboardingValidationError extends Error {
  readonly issues: readonly string[];

  constructor(issues: readonly string[]) {
    super("Onboarding request is invalid");
    this.name = "OnboardingValidationError";
    this.issues = Object.freeze([...issues]);
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function hasOnlyKeys(value: Record<string, unknown>, allowed: ReadonlySet<string>): boolean {
  return Object.keys(value).every((key) => allowed.has(key));
}

function optionalString(
  value: unknown,
  field: string,
  maxLength: number,
  issues: string[],
): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "string" || value.length === 0 || value.length > maxLength) {
    issues.push(`${field} must be a non-empty string of at most ${maxLength} characters`);
    return undefined;
  }
  return value;
}

export function parseOnboardAppRequest(
  value: unknown,
  targetPolicy: TargetPolicy,
): OnboardAppRequest {
  const issues: string[] = [];
  if (
    !isRecord(value) ||
    !hasOnlyKeys(value, new Set(["app", "authorization"])) ||
    !isRecord(value.app) ||
    !isRecord(value.authorization)
  ) {
    throw new OnboardingValidationError(["body must contain app and authorization objects"]);
  }
  const app = value.app;
  if (
    !hasOnlyKeys(
      app,
      new Set([
        "appName",
        "name",
        "description",
        "logo",
        "basePath",
        "frontendTarget",
        "owner",
        "healthcheck",
      ]),
    )
  ) {
    issues.push("app contains an unknown or immutable field");
  }
  const appName =
    typeof app.appName === "string" && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(app.appName)
      ? app.appName
      : "";
  if (!appName) issues.push("app.appName must be a lowercase kebab-case identifier");
  const name =
    typeof app.name === "string" && app.name.length > 0 && app.name.length <= 100
      ? app.name
      : "";
  if (!name) issues.push("app.name must contain 1 to 100 characters");
  const description =
    typeof app.description === "string" && app.description.length <= 280
      ? app.description
      : "";
  if (typeof app.description !== "string" || app.description.length > 280) {
    issues.push("app.description must contain at most 280 characters");
  }
  const logo = APPROVED_APP_LOGOS.includes(app.logo as ApprovedAppLogo)
    ? (app.logo as ApprovedAppLogo)
    : undefined;
  if (!logo) issues.push("app.logo is not an approved icon");
  const basePath =
    typeof app.basePath === "string" &&
    /^\/[a-z0-9]+(?:-[a-z0-9]+)*$/.test(app.basePath) &&
    !new Set(["/admin", "/api", "/app-unavailable", "/settings"]).has(app.basePath)
      ? app.basePath
      : "";
  if (!basePath) issues.push("app.basePath must be a non-reserved top-level path");

  let frontendTarget = "";
  if (typeof app.frontendTarget !== "string") {
    issues.push("app.frontendTarget must be an absolute origin");
  } else {
    try {
      frontendTarget = validateFrontendTarget(app.frontendTarget, targetPolicy);
    } catch {
      issues.push("app.frontendTarget is not allowed by the Registry target policy");
    }
  }
  const owner = optionalString(app.owner, "app.owner", 120, issues);
  const healthcheck = optionalString(
    app.healthcheck,
    "app.healthcheck",
    200,
    issues,
  );
  if (
    healthcheck !== undefined &&
    (!healthcheck.startsWith("/") || healthcheck.startsWith("//"))
  ) {
    issues.push("app.healthcheck must be an absolute path");
  }

  if (
    !hasOnlyKeys(value.authorization, new Set(["roles"])) ||
    !Array.isArray(value.authorization.roles) ||
    value.authorization.roles.length === 0 ||
    value.authorization.roles.length > 20
  ) {
    issues.push("authorization.roles must contain 1 to 20 roles");
  }
  const roleNames = new Set<string>();
  const roles = Array.isArray(value.authorization.roles)
    ? value.authorization.roles.flatMap((role, index): AppRoleDefinition[] => {
        if (
          !isRecord(role) ||
          !hasOnlyKeys(role, new Set(["name", "description"])) ||
          typeof role.name !== "string" ||
          !/^[a-z0-9]+(?:[-_:][a-z0-9]+)*$/.test(role.name) ||
          roleNames.has(role.name) ||
          typeof role.description !== "string" ||
          role.description.length === 0 ||
          role.description.length > 280
        ) {
          issues.push(`authorization.roles[${index}] is invalid or duplicated`);
          return [];
        }
        roleNames.add(role.name);
        return [
          Object.freeze({
            name: role.name,
            description: role.description,
          }),
        ];
      })
    : [];

  if (issues.length > 0 || !logo) throw new OnboardingValidationError(issues);
  return Object.freeze({
    app: Object.freeze({
      appName,
      name,
      description,
      logo,
      basePath,
      frontendTarget,
      ...(owner === undefined ? {} : { owner }),
      ...(healthcheck === undefined ? {} : { healthcheck }),
    }),
    authorization: Object.freeze({ roles: Object.freeze(roles) }),
  });
}
