import type {
  AppRoleDefinition,
  RegistryAppInput,
} from "./contracts.ts";
import { APPROVED_APP_LOGOS } from "./contracts.ts";

export type RegistryAdminApp = RegistryAppInput &
  Readonly<{
    active: boolean;
  }>;

export type RegistryRuntimeStatus = Readonly<{
  appName: string;
  healthy: boolean;
  shellCompatible: boolean;
  staticResources: boolean;
  checkedAt: string;
}>;

export interface RegistryAdminPort {
  createApp(
    app: RegistryAppInput,
    token: string,
    idempotencyKey: string,
  ): Promise<RegistryAdminApp>;
  listApps(token: string): Promise<readonly RegistryAdminApp[]>;
  activateApp(
    appName: string,
    token: string,
    idempotencyKey: string,
  ): Promise<RegistryAdminApp>;
  getRuntime(appName: string, token: string): Promise<RegistryRuntimeStatus>;
}

export interface AuthAdminPort {
  putRoles(
    appName: string,
    roles: readonly AppRoleDefinition[],
    token: string,
    idempotencyKey: string,
  ): Promise<void>;
}

export class DownstreamAdminError extends Error {
  readonly system: "registry" | "auth";
  readonly status?: number;

  constructor(
    system: "registry" | "auth",
    message: string,
    options?: Readonly<{ cause?: unknown; status?: number }>,
  ) {
    super(message, { cause: options?.cause });
    this.name = "DownstreamAdminError";
    this.system = system;
    this.status = options?.status;
  }
}

type ClientConfig = Readonly<{
  baseUrl: string;
  timeoutMs: number;
  responseLimitBytes: number;
}>;

function positiveInteger(value: string | undefined, fallback: number, name: string): number {
  if (value === undefined) return fallback;
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 1) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

function adminBaseUrl(value: string | undefined, fallback: string, name: string): string {
  const url = new URL(value ?? fallback);
  if (
    !["http:", "https:"].includes(url.protocol) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash
  ) {
    throw new Error(`${name} must be an HTTP(S) URL without credentials or query`);
  }
  return url.toString().replace(/\/$/, "");
}

function loadClientConfig(
  environment: Readonly<Record<string, string | undefined>>,
  variable: string,
  fallback: string,
): ClientConfig {
  return Object.freeze({
    baseUrl: adminBaseUrl(environment[variable], fallback, variable),
    timeoutMs: positiveInteger(
      environment.SAAS_ADMIN_TIMEOUT_MS,
      3_000,
      "SAAS_ADMIN_TIMEOUT_MS",
    ),
    responseLimitBytes: positiveInteger(
      environment.SAAS_ADMIN_RESPONSE_LIMIT_BYTES,
      262_144,
      "SAAS_ADMIN_RESPONSE_LIMIT_BYTES",
    ),
  });
}

async function readBoundedJson(
  response: Response,
  limitBytes: number,
  system: "registry" | "auth",
): Promise<unknown> {
  if (!response.body) {
    throw new DownstreamAdminError(system, `${system} returned an empty response`);
  }
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > limitBytes) {
      await reader.cancel();
      throw new DownstreamAdminError(system, `${system} response is too large`);
    }
    chunks.push(value);
  }
  const body = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder().decode(body)) as unknown;
  } catch (error) {
    throw new DownstreamAdminError(system, `${system} returned malformed JSON`, {
      cause: error,
    });
  }
}

class AdminJsonClient {
  readonly #config: ClientConfig;
  readonly #fetch: typeof fetch;
  readonly #system: "registry" | "auth";

  constructor(
    system: "registry" | "auth",
    config: ClientConfig,
    fetchImplementation: typeof fetch,
  ) {
    this.#system = system;
    this.#config = config;
    this.#fetch = fetchImplementation;
  }

  get baseUrl(): string {
    return this.#config.baseUrl;
  }

  async request(
    url: string,
    token: string,
    init?: Readonly<{
      method?: "GET" | "POST" | "PUT";
      body?: unknown;
      idempotencyKey?: string;
    }>,
  ): Promise<unknown> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.#config.timeoutMs);
    timeout.unref?.();
    try {
      const response = await this.#fetch(url, {
        method: init?.method ?? "GET",
        headers: {
          accept: "application/json",
          authorization: `Bearer ${token}`,
          ...(init?.body === undefined ? {} : { "content-type": "application/json" }),
          ...(init?.idempotencyKey
            ? { "idempotency-key": init.idempotencyKey }
            : {}),
        },
        ...(init?.body === undefined ? {} : { body: JSON.stringify(init.body) }),
        cache: "no-store",
        credentials: "omit",
        signal: controller.signal,
      });
      if (!response.ok) {
        await response.body?.cancel();
        throw new DownstreamAdminError(
          this.#system,
          `${this.#system} Admin API returned HTTP ${response.status}`,
          { status: response.status },
        );
      }
      return await readBoundedJson(
        response,
        this.#config.responseLimitBytes,
        this.#system,
      );
    } catch (error) {
      if (error instanceof DownstreamAdminError) throw error;
      throw new DownstreamAdminError(
        this.#system,
        `${this.#system} Admin API is unavailable`,
        { cause: error },
      );
    } finally {
      clearTimeout(timeout);
    }
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function parseRegistryApp(value: unknown): RegistryAdminApp {
  if (
    !isRecord(value) ||
    typeof value.appName !== "string" ||
    typeof value.name !== "string" ||
    typeof value.description !== "string" ||
    typeof value.logo !== "string" ||
    !APPROVED_APP_LOGOS.includes(value.logo as RegistryAdminApp["logo"]) ||
    typeof value.basePath !== "string" ||
    typeof value.frontendTarget !== "string" ||
    typeof value.active !== "boolean" ||
    (value.owner !== undefined && typeof value.owner !== "string") ||
    (value.healthcheck !== undefined && typeof value.healthcheck !== "string")
  ) {
    throw new DownstreamAdminError("registry", "Registry returned an invalid App");
  }
  return Object.freeze({
    appName: value.appName,
    name: value.name,
    description: value.description,
    logo: value.logo as RegistryAdminApp["logo"],
    basePath: value.basePath,
    frontendTarget: value.frontendTarget,
    active: value.active,
    ...(value.owner === undefined ? {} : { owner: value.owner as string }),
    ...(value.healthcheck === undefined
      ? {}
      : { healthcheck: value.healthcheck as string }),
  });
}

export class RegistryAdminClient implements RegistryAdminPort {
  readonly #client: AdminJsonClient;

  constructor(
    environment: Readonly<Record<string, string | undefined>> = process.env,
    fetchImplementation: typeof fetch = fetch,
  ) {
    this.#client = new AdminJsonClient(
      "registry",
      loadClientConfig(
        environment,
        "SAAS_REGISTRY_ADMIN_URL",
        "http://localhost:3200/admin/saas/apps",
      ),
      fetchImplementation,
    );
  }

  async createApp(
    app: RegistryAppInput,
    token: string,
    idempotencyKey: string,
  ): Promise<RegistryAdminApp> {
    return parseRegistryApp(
      await this.#client.request(this.#client.baseUrl, token, {
        method: "POST",
        body: app,
        idempotencyKey,
      }),
    );
  }

  async listApps(token: string): Promise<readonly RegistryAdminApp[]> {
    const value = await this.#client.request(this.#client.baseUrl, token);
    if (!isRecord(value) || !Array.isArray(value.apps)) {
      throw new DownstreamAdminError("registry", "Registry returned an invalid App list");
    }
    return Object.freeze(value.apps.map(parseRegistryApp));
  }

  async activateApp(
    appName: string,
    token: string,
    idempotencyKey: string,
  ): Promise<RegistryAdminApp> {
    return parseRegistryApp(
      await this.#client.request(
        `${this.#client.baseUrl}/${encodeURIComponent(appName)}/activate`,
        token,
        { method: "POST", idempotencyKey },
      ),
    );
  }

  async getRuntime(appName: string, token: string): Promise<RegistryRuntimeStatus> {
    const value = await this.#client.request(
      `${this.#client.baseUrl}/${encodeURIComponent(appName)}/runtime`,
      token,
    );
    if (
      !isRecord(value) ||
      value.appName !== appName ||
      typeof value.healthy !== "boolean" ||
      typeof value.shellCompatible !== "boolean" ||
      typeof value.staticResources !== "boolean" ||
      typeof value.checkedAt !== "string"
    ) {
      throw new DownstreamAdminError(
        "registry",
        "Registry returned an invalid runtime status",
      );
    }
    return Object.freeze({
      appName,
      healthy: value.healthy,
      shellCompatible: value.shellCompatible,
      staticResources: value.staticResources,
      checkedAt: value.checkedAt,
    });
  }
}

export class AuthAdminClient implements AuthAdminPort {
  readonly #client: AdminJsonClient;

  constructor(
    environment: Readonly<Record<string, string | undefined>> = process.env,
    fetchImplementation: typeof fetch = fetch,
  ) {
    this.#client = new AdminJsonClient(
      "auth",
      loadClientConfig(
        environment,
        "SAAS_AUTH_ADMIN_URL",
        "http://localhost:3200/admin/saas/apps",
      ),
      fetchImplementation,
    );
  }

  async putRoles(
    appName: string,
    roles: readonly AppRoleDefinition[],
    token: string,
    idempotencyKey: string,
  ): Promise<void> {
    const value = await this.#client.request(
      `${this.#client.baseUrl}/${encodeURIComponent(appName)}/roles`,
      token,
      {
        method: "PUT",
        body: { roles },
        idempotencyKey,
      },
    );
    if (!isRecord(value) || value.appName !== appName || !Array.isArray(value.roles)) {
      throw new DownstreamAdminError("auth", "Auth Service returned invalid roles");
    }
  }
}
