import assert from "node:assert/strict";
import test from "node:test";

import {
  AuthAdminClient,
  DownstreamAdminError,
  RegistryAdminClient,
} from "./clients.ts";
import type { RegistryAppInput } from "./contracts.ts";

const app: RegistryAppInput = {
  appName: "risk-dashboard",
  name: "Risk Dashboard",
  description: "Risk reports",
  logo: "ChartBar",
  basePath: "/risk",
  frontendTarget: "https://risk.company.net",
};

function environment(
  overrides: Readonly<Record<string, string | undefined>> = {},
): Readonly<Record<string, string | undefined>> {
  return {
    FRAME_REGISTRY_ADMIN_URL: "https://registry.internal/admin/frame/apps",
    FRAME_AUTH_ADMIN_URL: "https://auth.internal/admin/frame/apps",
    ...overrides,
  };
}

test("sends only the DSP Bearer token and one idempotency key to Registry", async () => {
  let observedUrl = "";
  let observedInit: RequestInit | undefined;
  const client = new RegistryAdminClient(
    environment(),
    async (input, init) => {
      observedUrl = String(input);
      observedInit = init;
      return Response.json({ ...app, active: false });
    },
  );

  const created = await client.createApp(app, "opaque-dsp-token", "logical-1");

  assert.equal(observedUrl, "https://registry.internal/admin/frame/apps");
  assert.equal(observedInit?.method, "POST");
  assert.equal(observedInit?.credentials, "omit");
  assert.deepEqual(observedInit?.headers, {
    accept: "application/json",
    authorization: "Bearer opaque-dsp-token",
    "content-type": "application/json",
    "idempotency-key": "logical-1",
  });
  assert.deepEqual(JSON.parse(String(observedInit?.body)), app);
  assert.equal(created.active, false);
});

test("keeps Auth role administration on its independent endpoint", async () => {
  let observedUrl = "";
  let observedInit: RequestInit | undefined;
  const roles = [{ name: "risk-user", description: "Can view risk reports" }];
  const client = new AuthAdminClient(
    environment(),
    async (input, init) => {
      observedUrl = String(input);
      observedInit = init;
      return Response.json({ appName: app.appName, roles });
    },
  );

  await client.putRoles(app.appName, roles, "opaque-dsp-token", "logical-1");

  assert.equal(
    observedUrl,
    "https://auth.internal/admin/frame/apps/risk-dashboard/roles",
  );
  assert.equal(observedInit?.method, "PUT");
  assert.deepEqual(JSON.parse(String(observedInit?.body)), { roles });
});

test("rejects oversized and malformed Registry Admin responses", async () => {
  const oversized = new RegistryAdminClient(
    environment({ FRAME_ADMIN_RESPONSE_LIMIT_BYTES: "8" }),
    async () => Response.json({ ...app, active: false }),
  );
  await assert.rejects(
    () => oversized.listApps("token"),
    (error: unknown) =>
      error instanceof DownstreamAdminError &&
      error.system === "registry" &&
      /too large/.test(error.message),
  );

  const malformed = new RegistryAdminClient(environment(), async () =>
    Response.json({ apps: [{ appName: app.appName, active: false }] }),
  );
  await assert.rejects(
    () => malformed.listApps("token"),
    (error: unknown) =>
      error instanceof DownstreamAdminError && error.system === "registry",
  );
});
