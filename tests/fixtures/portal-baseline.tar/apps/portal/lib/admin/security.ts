import {
  SaasPermissionsClient,
  SaasPermissionsError,
  hasSaasAdminRole,
  readDspToken,
} from "@saas-platform/auth";

export class AdminAuthorizationError extends Error {
  readonly status: 401 | 403;

  constructor(status: 401 | 403) {
    super(status === 401 ? "Authentication is required" : "Admin role is required");
    this.name = "AdminAuthorizationError";
    this.status = status;
  }
}

export class AdminRequestError extends Error {
  readonly status: 400 | 413 | 415 | 429;

  constructor(status: AdminRequestError["status"], message: string) {
    super(message);
    this.name = "AdminRequestError";
    this.status = status;
  }
}

type AdminPrincipal = Readonly<{
  userId: string;
  token: string;
}>;

type RateWindow = {
  count: number;
  resetsAt: number;
};

const rateWindows = new Map<string, RateWindow>();
const RATE_WINDOW_MS = 60_000;
const RATE_LIMIT = 20;
const REQUEST_LIMIT_BYTES = 65_536;

export async function authorizeSaasAdmin(
  request: Request,
  client = new SaasPermissionsClient(),
): Promise<AdminPrincipal> {
  try {
    const token = readDspToken(request, client.config.tokenCookieName);
    const [currentUser, permissions] = await Promise.all([
      client.getCurrentUser(request),
      client.get(request),
    ]);
    if (!hasSaasAdminRole(permissions, client.config.adminRoles)) {
      throw new AdminAuthorizationError(403);
    }
    return Object.freeze({ userId: currentUser.id, token });
  } catch (error) {
    if (error instanceof AdminAuthorizationError) throw error;
    if (error instanceof SaasPermissionsError) {
      throw new AdminAuthorizationError(
        error.category === "missing_token" ? 401 : 403,
      );
    }
    throw error;
  }
}

export function requireSameOrigin(request: Request): void {
  const origin = request.headers.get("origin");
  const requestUrl = new URL(request.url);
  const host = request.headers.get("host");
  const forwardedProtocol =
    process.env.SAAS_TRUST_PROXY_HEADERS === "true"
      ? request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim()
      : undefined;
  const protocol = forwardedProtocol ? `${forwardedProtocol}:` : requestUrl.protocol;
  const expectedOrigin = host ? `${protocol}//${host}` : requestUrl.origin;
  if (!origin || origin !== expectedOrigin) {
    throw new AdminAuthorizationError(403);
  }
}

export function enforceAdminRateLimit(userId: string, operation: string): void {
  const now = Date.now();
  const key = `${userId}:${operation}`;
  const window = rateWindows.get(key);
  if (!window || window.resetsAt <= now) {
    rateWindows.set(key, { count: 1, resetsAt: now + RATE_WINDOW_MS });
    return;
  }
  if (window.count >= RATE_LIMIT) {
    throw new AdminRequestError(429, "Admin mutation rate limit exceeded");
  }
  window.count += 1;
}

export async function readAdminJsonBody(request: Request): Promise<unknown> {
  const contentType = request.headers.get("content-type")?.toLowerCase() ?? "";
  if (!contentType.startsWith("application/json")) {
    throw new AdminRequestError(415, "content-type: application/json is required");
  }
  const declaredLength = Number(request.headers.get("content-length"));
  if (Number.isFinite(declaredLength) && declaredLength > REQUEST_LIMIT_BYTES) {
    throw new AdminRequestError(413, "Admin request body is too large");
  }
  if (!request.body) throw new AdminRequestError(400, "A JSON body is required");
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > REQUEST_LIMIT_BYTES) {
      await reader.cancel();
      throw new AdminRequestError(413, "Admin request body is too large");
    }
    chunks.push(value);
  }
  const body = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder().decode(body)) as unknown;
  } catch {
    throw new AdminRequestError(400, "Admin request body is malformed");
  }
}
