import { resolve } from "node:path";

import { Pool } from "pg";

import { runPortalMigrations } from "../lib/preferences/migration-runner.ts";

const connectionString = process.env.PORTAL_DATABASE_URL;
if (!connectionString) throw new Error("PORTAL_DATABASE_URL is required");

const pool = new Pool({
  connectionString,
  max: 1,
  connectionTimeoutMillis: 5_000,
  application_name: "saas-portal-migrator",
});

try {
  await runPortalMigrations(pool, resolve(import.meta.dirname, "../migrations"));
  console.log("Portal PostgreSQL migrations are current");
} finally {
  await pool.end();
}
