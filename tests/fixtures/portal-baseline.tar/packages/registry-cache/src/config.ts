import type {
  RegistryClientConfig,
  RegistryRuntimeConfig,
} from "./types.ts";

export function parseAllowedHosts(value: string | undefined): readonly string[] {
  const entries = (value ?? "localhost,.svc.cluster.local,.company.net")
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);

  if (entries.length === 0) {
    throw new Error("SAAS_ALLOWED_TARGET_HOSTS must contain at least one host");
  }
  return entries;
}

function parsePositiveInteger(value: string | undefined, fallback: number, name: string): number {
  if (value === undefined) return fallback;
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 1) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

function parseAllowedPorts(value: string | undefined): readonly string[] | undefined {
  if (value === undefined) return undefined;
  const ports = value
    .split(",")
    .map((port) => port.trim())
    .filter(Boolean);
  if (
    ports.length === 0 ||
    ports.some((port) => !/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65_535)
  ) {
    throw new Error("SAAS_ALLOWED_TARGET_PORTS must contain valid TCP ports");
  }
  return ports;
}

export function loadRegistryRuntimeConfig(
  environment: Readonly<Record<string, string | undefined>>,
): RegistryRuntimeConfig {
  const pollMinMs = parsePositiveInteger(
    environment.SAAS_REGISTRY_POLL_MIN_MS,
    3_000,
    "SAAS_REGISTRY_POLL_MIN_MS",
  );
  const pollMaxMs = parsePositiveInteger(
    environment.SAAS_REGISTRY_POLL_MAX_MS,
    5_000,
    "SAAS_REGISTRY_POLL_MAX_MS",
  );
  if (pollMaxMs < pollMinMs) {
    throw new Error("SAAS_REGISTRY_POLL_MAX_MS must be >= SAAS_REGISTRY_POLL_MIN_MS");
  }

  return Object.freeze({
    client: Object.freeze({
      endpoint:
        environment.SAAS_REGISTRY_URL ??
        "http://localhost:3200/internal/saas/registry/routes",
      timeoutMs: parsePositiveInteger(
        environment.SAAS_REGISTRY_TIMEOUT_MS,
        2_000,
        "SAAS_REGISTRY_TIMEOUT_MS",
      ),
      responseSizeLimitBytes: parsePositiveInteger(
        environment.SAAS_REGISTRY_RESPONSE_LIMIT_BYTES,
        262_144,
        "SAAS_REGISTRY_RESPONSE_LIMIT_BYTES",
      ),
    }),
    targetPolicy: Object.freeze({
      allowedHosts: parseAllowedHosts(environment.SAAS_ALLOWED_TARGET_HOSTS),
      allowedPorts: parseAllowedPorts(environment.SAAS_ALLOWED_TARGET_PORTS),
      allowHttp: environment.SAAS_ALLOW_HTTP_TARGETS === "true",
    }),
    pollMinMs,
    pollMaxMs,
  });
}

export function loadRegistryCatalogConfig(
  environment: Readonly<Record<string, string | undefined>>,
): RegistryClientConfig {
  return Object.freeze({
    endpoint:
      environment.SAAS_REGISTRY_CATALOG_URL ??
      "http://localhost:3200/internal/saas/registry/apps",
    timeoutMs: parsePositiveInteger(
      environment.SAAS_REGISTRY_TIMEOUT_MS,
      2_000,
      "SAAS_REGISTRY_TIMEOUT_MS",
    ),
    responseSizeLimitBytes: parsePositiveInteger(
      environment.SAAS_REGISTRY_RESPONSE_LIMIT_BYTES,
      262_144,
      "SAAS_REGISTRY_RESPONSE_LIMIT_BYTES",
    ),
  });
}
