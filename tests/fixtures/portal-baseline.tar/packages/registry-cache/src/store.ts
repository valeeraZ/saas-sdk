import { ImmutableRouteTable } from "./snapshot.ts";
import type {
  RegistryErrorCategory,
  RouteSnapshot,
  TargetPolicy,
} from "./types.ts";
import { validateSnapshot } from "./validation.ts";

export type LastPollResult = "never" | "updated" | "not-modified" | "failed";

export type RouteStoreStatus = Readonly<{
  ready: boolean;
  polling: boolean;
  version: number | null;
  generatedAt: string | null;
  snapshotAgeMs: number | null;
  installedAt: string | null;
  lastPollAttemptAt: string | null;
  lastPollCompletedAt: string | null;
  lastSuccessAt: string | null;
  lastPollResult: LastPollResult;
  lastErrorCategory: RegistryErrorCategory | null;
}>;

export class StaleSnapshotError extends Error {
  readonly category = "stale-version" as const;

  constructor(receivedVersion: number, installedVersion: number) {
    super(
      `Registry snapshot version ${receivedVersion} is not newer than installed version ${installedVersion}`,
    );
    this.name = "StaleSnapshotError";
  }
}

export class AtomicRouteStore {
  readonly #policy: TargetPolicy;
  #table: ImmutableRouteTable | undefined;
  #etag: string | undefined;
  #polling = false;
  #installedAt: number | undefined;
  #lastPollAttemptAt: number | undefined;
  #lastPollCompletedAt: number | undefined;
  #lastSuccessAt: number | undefined;
  #lastPollResult: LastPollResult = "never";
  #lastErrorCategory: RegistryErrorCategory | undefined;

  constructor(policy: TargetPolicy) {
    this.#policy = policy;
  }

  get table(): ImmutableRouteTable | undefined {
    return this.#table;
  }

  get etag(): string | undefined {
    return this.#etag;
  }

  beginPoll(now = Date.now()): boolean {
    if (this.#polling) return false;
    this.#polling = true;
    this.#lastPollAttemptAt = now;
    return true;
  }

  install(snapshot: unknown, etag: string, now = Date.now()): ImmutableRouteTable {
    const validated = validateSnapshot(snapshot, this.#policy);
    if (this.#table && validated.version <= this.#table.version) {
      throw new StaleSnapshotError(validated.version, this.#table.version);
    }

    const nextTable = new ImmutableRouteTable(validated);
    this.#table = nextTable;
    this.#etag = etag;
    this.#installedAt = now;
    this.#recordSuccess("updated", now);
    return nextTable;
  }

  notModified(etag: string, now = Date.now()): void {
    if (!this.#table) {
      throw new Error("Registry returned 304 before an initial snapshot was installed");
    }
    this.#etag = etag;
    this.#recordSuccess("not-modified", now);
  }

  fail(category: RegistryErrorCategory, now = Date.now()): void {
    this.#polling = false;
    this.#lastPollCompletedAt = now;
    this.#lastPollResult = "failed";
    this.#lastErrorCategory = category;
  }

  status(now = Date.now()): RouteStoreStatus {
    const generatedTime = this.#table ? Date.parse(this.#table.generatedAt) : Number.NaN;
    return Object.freeze({
      ready: Boolean(this.#table),
      polling: this.#polling,
      version: this.#table?.version ?? null,
      generatedAt: this.#table?.generatedAt ?? null,
      snapshotAgeMs: Number.isNaN(generatedTime) ? null : Math.max(0, now - generatedTime),
      installedAt: this.#toIso(this.#installedAt),
      lastPollAttemptAt: this.#toIso(this.#lastPollAttemptAt),
      lastPollCompletedAt: this.#toIso(this.#lastPollCompletedAt),
      lastSuccessAt: this.#toIso(this.#lastSuccessAt),
      lastPollResult: this.#lastPollResult,
      lastErrorCategory: this.#lastErrorCategory ?? null,
    });
  }

  #recordSuccess(result: Exclude<LastPollResult, "never" | "failed">, now: number): void {
    this.#polling = false;
    this.#lastPollCompletedAt = now;
    this.#lastSuccessAt = now;
    this.#lastPollResult = result;
    this.#lastErrorCategory = undefined;
  }

  #toIso(value: number | undefined): string | null {
    return value === undefined ? null : new Date(value).toISOString();
  }
}
