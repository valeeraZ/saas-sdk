import type {
  FrameRoute,
  RegistryCatalogSnapshot,
  RegistryNavigationApp,
  RouteSnapshot,
  TargetPolicy,
} from "./types.ts";

const APP_NAME_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const BASE_PATH_PATTERN = /^\/[a-z0-9]+(?:-[a-z0-9]+)*$/;
const RESERVED_BASE_PATHS = new Set([
  "/admin",
  "/api",
  "/app-unavailable",
  "/settings",
]);

function isAllowedHost(hostname: string, allowedHosts: readonly string[]): boolean {
  const normalizedHostname = hostname.toLowerCase();

  return allowedHosts.some((entry) => {
    const normalizedEntry = entry.trim().toLowerCase();
    if (normalizedEntry.startsWith("*.")) {
      return normalizedHostname.endsWith(normalizedEntry.slice(1));
    }
    if (normalizedEntry.startsWith(".")) {
      return normalizedHostname.endsWith(normalizedEntry);
    }
    return normalizedHostname === normalizedEntry;
  });
}

export function validateFrontendTarget(
  frontendTarget: string,
  policy: TargetPolicy,
): string {
  let target: URL;
  try {
    target = new URL(frontendTarget);
  } catch {
    throw new Error(`Invalid frontendTarget URL: ${frontendTarget}`);
  }

  if (target.protocol !== "https:" && !(policy.allowHttp && target.protocol === "http:")) {
    throw new Error(`frontendTarget uses a disallowed protocol: ${target.protocol}`);
  }
  if (target.username || target.password) {
    throw new Error("frontendTarget must not contain credentials");
  }
  if (target.pathname !== "/" || target.search || target.hash) {
    throw new Error("frontendTarget must be an origin without path, query, or fragment");
  }
  if (!isAllowedHost(target.hostname, policy.allowedHosts)) {
    throw new Error(`frontendTarget host is not allowlisted: ${target.hostname}`);
  }
  const effectivePort = target.port || (target.protocol === "https:" ? "443" : "80");
  if (policy.allowedPorts && !policy.allowedPorts.includes(effectivePort)) {
    throw new Error(`frontendTarget port is not allowlisted: ${effectivePort}`);
  }

  return target.origin;
}

function validateRoute(route: FrameRoute, policy: TargetPolicy): FrameRoute {
  if (typeof route.appName !== "string" || !APP_NAME_PATTERN.test(route.appName)) {
    throw new Error(`Invalid appName: ${route.appName}`);
  }
  if (
    typeof route.basePath !== "string" ||
    !BASE_PATH_PATTERN.test(route.basePath) ||
    RESERVED_BASE_PATHS.has(route.basePath)
  ) {
    throw new Error(`Invalid or reserved basePath: ${route.basePath}`);
  }
  if (typeof route.active !== "boolean") {
    throw new Error(`active must be boolean for ${route.appName}`);
  }
  if (typeof route.frontendTarget !== "string") {
    throw new Error(`Invalid frontendTarget for ${route.appName}`);
  }

  return Object.freeze({
    appName: route.appName,
    basePath: route.basePath,
    frontendTarget: validateFrontendTarget(route.frontendTarget, policy),
    active: route.active,
  });
}

function isRecord(input: unknown): input is Record<string, unknown> {
  return typeof input === "object" && input !== null && !Array.isArray(input);
}

const CATALOG_APP_FIELDS = new Set([
  "appName",
  "name",
  "description",
  "logo",
  "basePath",
  "active",
]);

function validateCatalogApp(
  input: Record<string, unknown>,
  appNames: Set<string>,
  basePaths: Set<string>,
): RegistryNavigationApp {
  if (Object.keys(input).some((key) => !CATALOG_APP_FIELDS.has(key))) {
    throw new Error("Registry catalog App contains a server-only or unknown field");
  }
  const { appName, name, description, logo, basePath, active } = input;
  if (
    typeof appName !== "string" ||
    !APP_NAME_PATTERN.test(appName) ||
    appNames.has(appName)
  ) {
    throw new Error(`Invalid or duplicate catalog appName: ${String(appName)}`);
  }
  if (
    typeof basePath !== "string" ||
    !BASE_PATH_PATTERN.test(basePath) ||
    RESERVED_BASE_PATHS.has(basePath) ||
    basePaths.has(basePath)
  ) {
    throw new Error(`Invalid or duplicate catalog basePath: ${String(basePath)}`);
  }
  if (
    typeof name !== "string" ||
    name.length === 0 ||
    typeof description !== "string" ||
    typeof logo !== "string" ||
    logo.length === 0 ||
    typeof active !== "boolean"
  ) {
    throw new Error(`Invalid Registry catalog metadata for ${appName}`);
  }
  appNames.add(appName);
  basePaths.add(basePath);
  return Object.freeze({ appName, name, description, logo, basePath, active });
}

export function validateCatalogSnapshot(input: unknown): RegistryCatalogSnapshot {
  if (
    !isRecord(input) ||
    Object.keys(input).some((key) => key !== "version" && key !== "apps") ||
    typeof input.version !== "number" ||
    !Number.isSafeInteger(input.version) ||
    input.version < 1 ||
    !Array.isArray(input.apps)
  ) {
    throw new Error("Registry catalog must contain a positive version and Apps array");
  }
  const appNames = new Set<string>();
  const basePaths = new Set<string>();
  const apps = input.apps.map((app) => {
    if (!isRecord(app)) throw new Error("Each Registry catalog App must be an object");
    return validateCatalogApp(app, appNames, basePaths);
  });
  return Object.freeze({
    version: input.version,
    apps: Object.freeze(apps),
  });
}

export function validateSnapshot(input: unknown, policy: TargetPolicy): RouteSnapshot {
  if (!isRecord(input)) {
    throw new Error("Route snapshot must be an object");
  }
  const version = input.version;
  if (typeof version !== "number" || !Number.isSafeInteger(version) || version < 1) {
    throw new Error("Route snapshot version must be a positive integer");
  }
  if (typeof input.generatedAt !== "string" || Number.isNaN(Date.parse(input.generatedAt))) {
    throw new Error("Route snapshot generatedAt must be an ISO date");
  }
  if (!Array.isArray(input.routes)) {
    throw new Error("Route snapshot routes must be an array");
  }

  const appNames = new Set<string>();
  const basePaths = new Set<string>();
  const routes = input.routes.map((route) => {
    if (!isRecord(route)) {
      throw new Error("Each route must be an object");
    }
    const validated = validateRoute(route as FrameRoute, policy);
    if (appNames.has(validated.appName)) {
      throw new Error(`Duplicate appName: ${validated.appName}`);
    }
    if (basePaths.has(validated.basePath)) {
      throw new Error(`Duplicate basePath: ${validated.basePath}`);
    }
    appNames.add(validated.appName);
    basePaths.add(validated.basePath);
    return validated;
  });

  return Object.freeze({
    version,
    generatedAt: input.generatedAt,
    routes: Object.freeze(routes),
  });
}
