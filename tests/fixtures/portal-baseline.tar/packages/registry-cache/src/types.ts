export type FrameRoute = Readonly<{
  appName: string;
  basePath: string;
  frontendTarget: string;
  active: boolean;
}>;

export type RouteSnapshot = Readonly<{
  version: number;
  generatedAt: string;
  routes: readonly FrameRoute[];
}>;

export type RegistryNavigationApp = Readonly<{
  appName: string;
  name: string;
  description: string;
  logo: string;
  basePath: string;
  active: boolean;
}>;

export type RegistryCatalogSnapshot = Readonly<{
  version: number;
  apps: readonly RegistryNavigationApp[];
}>;

export type TargetPolicy = Readonly<{
  allowedHosts: readonly string[];
  allowedPorts?: readonly string[];
  allowHttp?: boolean;
}>;

export type RegistryErrorCategory =
  | "configuration"
  | "network"
  | "timeout"
  | "response-too-large"
  | "http"
  | "protocol"
  | "parse"
  | "validation"
  | "stale-version";

export type RegistryClientConfig = Readonly<{
  endpoint: string;
  timeoutMs: number;
  responseSizeLimitBytes: number;
}>;

export type RegistryRuntimeConfig = Readonly<{
  client: RegistryClientConfig;
  targetPolicy: TargetPolicy;
  pollMinMs: number;
  pollMaxMs: number;
}>;
