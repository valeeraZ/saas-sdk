import assert from "node:assert/strict";
import test from "node:test";

import { RegistryCatalogClient } from "./catalog.ts";

test("keeps a bounded ETag-backed Registry catalog snapshot", async () => {
  const etags: Array<string | undefined> = [];
  let call = 0;
  const client = new RegistryCatalogClient({
    async fetchSnapshot(etag?: string) {
      etags.push(etag);
      call += 1;
      if (call === 2) return { kind: "not-modified", etag: '"apps-v1"' };
      return {
        kind: "snapshot",
        etag: '"apps-v1"',
        snapshot: {
          version: 1,
          apps: [
            {
              appName: "risk-dashboard",
              name: "Risk Dashboard",
              description: "Risk reports",
              logo: "ChartBar",
              basePath: "/risk",
              active: true,
            },
          ],
        },
      };
    },
  });

  const first = await client.get();
  const second = await client.get();
  assert.equal(second, first);
  assert.deepEqual(etags, [undefined, '"apps-v1"']);
});
