import {
  RegistryHttpClient,
  type RegistryFetchResult,
} from "./client.ts";
import type {
  RegistryCatalogSnapshot,
  RegistryClientConfig,
} from "./types.ts";
import { validateCatalogSnapshot } from "./validation.ts";

export class RegistryCatalogClient {
  readonly #client: Pick<RegistryHttpClient, "fetchSnapshot">;
  #etag: string | undefined;
  #snapshot: RegistryCatalogSnapshot | undefined;

  constructor(
    configOrClient:
      | RegistryClientConfig
      | Pick<RegistryHttpClient, "fetchSnapshot">,
    fetchImplementation: typeof fetch = fetch,
  ) {
    this.#client =
      "endpoint" in configOrClient
        ? new RegistryHttpClient(configOrClient, fetchImplementation)
        : configOrClient;
  }

  async get(signal?: AbortSignal): Promise<RegistryCatalogSnapshot> {
    const result: RegistryFetchResult = await this.#client.fetchSnapshot(
      this.#etag,
      signal,
    );
    if (result.kind === "not-modified") {
      if (!this.#snapshot || result.etag !== this.#etag) {
        throw new Error("Registry returned 304 without a matching catalog snapshot");
      }
      return this.#snapshot;
    }

    const snapshot = validateCatalogSnapshot(result.snapshot);
    this.#etag = result.etag;
    this.#snapshot = snapshot;
    return snapshot;
  }
}
