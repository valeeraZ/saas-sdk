import type {
  RegistryClientConfig,
  RegistryErrorCategory,
} from "./types.ts";

export type RegistryFetchResult =
  | Readonly<{ kind: "not-modified"; etag: string }>
  | Readonly<{ kind: "snapshot"; etag: string; snapshot: unknown }>;

export class RegistryClientError extends Error {
  readonly category: RegistryErrorCategory;
  readonly status?: number;

  constructor(
    category: RegistryErrorCategory,
    message: string,
    options?: Readonly<{ cause?: unknown; status?: number }>,
  ) {
    super(message, { cause: options?.cause });
    this.name = "RegistryClientError";
    this.category = category;
    this.status = options?.status;
  }
}

function parseEndpoint(value: string): string {
  let endpoint: URL;
  try {
    endpoint = new URL(value);
  } catch (error) {
    throw new RegistryClientError("configuration", "Registry endpoint must be a valid URL", {
      cause: error,
    });
  }

  if (!["http:", "https:"].includes(endpoint.protocol)) {
    throw new RegistryClientError(
      "configuration",
      `Registry endpoint uses a disallowed protocol: ${endpoint.protocol}`,
    );
  }
  if (endpoint.username || endpoint.password || endpoint.hash) {
    throw new RegistryClientError(
      "configuration",
      "Registry endpoint must not contain credentials or a fragment",
    );
  }
  if (endpoint.search) {
    throw new RegistryClientError(
      "configuration",
      "Registry endpoint must not contain query parameters",
    );
  }
  return endpoint.href;
}

function requirePositiveInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new RegistryClientError("configuration", `${name} must be a positive integer`);
  }
  return value;
}

function requireEtag(response: Response): string {
  const etag = response.headers.get("etag")?.trim();
  if (!etag) {
    throw new RegistryClientError("protocol", "Registry response is missing an ETag");
  }
  return etag;
}

async function readLimitedBody(response: Response, limit: number): Promise<Uint8Array> {
  const declaredLength = response.headers.get("content-length");
  if (declaredLength) {
    const parsedLength = Number(declaredLength);
    if (Number.isFinite(parsedLength) && parsedLength > limit) {
      await response.body?.cancel();
      throw new RegistryClientError(
        "response-too-large",
        `Registry response exceeds ${limit} bytes`,
      );
    }
  }

  if (!response.body) return new Uint8Array();
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > limit) {
        await reader.cancel();
        throw new RegistryClientError(
          "response-too-large",
          `Registry response exceeds ${limit} bytes`,
        );
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }

  const body = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return body;
}

export class RegistryHttpClient {
  readonly #config: RegistryClientConfig;
  readonly #fetch: typeof fetch;

  constructor(config: RegistryClientConfig, fetchImplementation: typeof fetch = fetch) {
    this.#config = Object.freeze({
      endpoint: parseEndpoint(config.endpoint),
      timeoutMs: requirePositiveInteger(config.timeoutMs, "Registry timeout"),
      responseSizeLimitBytes: requirePositiveInteger(
        config.responseSizeLimitBytes,
        "Registry response size limit",
      ),
    });
    this.#fetch = fetchImplementation;
  }

  async fetchSnapshot(etag?: string, signal?: AbortSignal): Promise<RegistryFetchResult> {
    const timeoutController = new AbortController();
    const requestController = new AbortController();
    const timeout = setTimeout(() => timeoutController.abort(), this.#config.timeoutMs);
    timeout.unref?.();
    const abortRequest = () => requestController.abort();
    timeoutController.signal.addEventListener("abort", abortRequest, { once: true });
    signal?.addEventListener("abort", abortRequest, { once: true });
    if (signal?.aborted) abortRequest();

    try {
      let response: Response;
      try {
        response = await this.#fetch(this.#config.endpoint, {
          cache: "no-store",
          headers: {
            accept: "application/json",
            ...(etag ? { "if-none-match": etag } : {}),
          },
          signal: requestController.signal,
        });
      } catch (error) {
        if (timeoutController.signal.aborted) {
          throw new RegistryClientError("timeout", "Registry request timed out", { cause: error });
        }
        if (signal?.aborted) {
          throw new RegistryClientError("network", "Registry request was cancelled", {
            cause: error,
          });
        }
        throw new RegistryClientError("network", "Registry request failed", { cause: error });
      }

      if (response.status === 304) {
        return { kind: "not-modified", etag: requireEtag(response) };
      }
      if (!response.ok) {
        await response.body?.cancel();
        throw new RegistryClientError(
          "http",
          `Registry returned HTTP ${response.status}`,
          { status: response.status },
        );
      }

      const responseEtag = requireEtag(response);
      const bytes = await readLimitedBody(response, this.#config.responseSizeLimitBytes);
      let snapshot: unknown;
      try {
        snapshot = JSON.parse(new TextDecoder().decode(bytes)) as unknown;
      } catch (error) {
        throw new RegistryClientError("parse", "Registry response is not valid JSON", {
          cause: error,
        });
      }
      return { kind: "snapshot", etag: responseEtag, snapshot };
    } catch (error) {
      if (error instanceof RegistryClientError) throw error;
      if (timeoutController.signal.aborted) {
        throw new RegistryClientError("timeout", "Registry response timed out", { cause: error });
      }
      throw new RegistryClientError(
        "network",
        signal?.aborted ? "Registry request was cancelled" : "Registry response failed",
        { cause: error },
      );
    } finally {
      clearTimeout(timeout);
      timeoutController.signal.removeEventListener("abort", abortRequest);
      signal?.removeEventListener("abort", abortRequest);
    }
  }
}
