import type { SaasRoute, RouteSnapshot } from "./types.ts";

export class ImmutableRouteTable {
  readonly #routes: readonly SaasRoute[];
  readonly version: number;
  readonly generatedAt: string;

  constructor(snapshot: RouteSnapshot) {
    this.version = snapshot.version;
    this.generatedAt = snapshot.generatedAt;
    this.#routes = Object.freeze(
      [...snapshot.routes].sort((left, right) => right.basePath.length - left.basePath.length),
    );
  }

  match(pathname: string): SaasRoute | undefined {
    return this.#routes.find(
      (route) => pathname === route.basePath || pathname.startsWith(`${route.basePath}/`),
    );
  }

  list(): readonly SaasRoute[] {
    return this.#routes;
  }
}

export function buildUpstreamUrl(route: SaasRoute, pathname: string, search: string): URL {
  const target = new URL(route.frontendTarget);
  target.pathname = pathname;
  target.search = search;
  return target;
}
