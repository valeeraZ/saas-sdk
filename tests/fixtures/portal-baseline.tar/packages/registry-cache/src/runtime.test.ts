import assert from "node:assert/strict";
import test from "node:test";

import { RegistryClientError, type RegistryFetchResult } from "./client.ts";
import { RegistryPoller } from "./poller.ts";
import { AtomicRouteStore } from "./store.ts";
import type { RouteSnapshot } from "./types.ts";

const policy = { allowedHosts: [".company.net"] } as const;

function createSnapshot(version: number, active = true): RouteSnapshot {
  return {
    version,
    generatedAt: new Date().toISOString(),
    routes: [
      {
        appName: "risk-dashboard",
        basePath: "/risk",
        frontendTarget: "https://risk.company.net",
        active,
      },
    ],
  };
}

function createPoller(
  store: AtomicRouteStore,
  fetchSnapshot: (etag?: string) => Promise<RegistryFetchResult>,
) {
  return new RegistryPoller({ fetchSnapshot }, store, {
    minIntervalMs: 3_000,
    maxIntervalMs: 5_000,
  });
}

test("installs only complete, valid, increasing snapshots", async () => {
  const store = new AtomicRouteStore(policy);
  store.beginPoll(1_000);
  store.install(createSnapshot(2), '"routes-v2"', 1_100);
  const originalTable = store.table;

  store.beginPoll(1_200);
  assert.throws(
    () => store.install({ ...createSnapshot(3), routes: [{ broken: true }] }, '"routes-v3"'),
    /Invalid appName/,
  );
  store.fail("validation", 1_300);
  assert.equal(store.table, originalTable);
  assert.equal(store.etag, '"routes-v2"');

  store.beginPoll(1_400);
  assert.throws(() => store.install(createSnapshot(1), '"routes-v1-again"'), /not newer/);
  store.fail("stale-version", 1_500);
  assert.equal(store.table, originalTable);
  assert.equal(store.status(1_600).lastErrorCategory, "stale-version");
});

test("initial Registry outage leaves a new replica unready", async () => {
  const store = new AtomicRouteStore(policy);
  const poller = createPoller(store, async () => {
    throw new RegistryClientError("network", "connection refused");
  });

  assert.equal(await poller.pollOnce(), "failed");
  assert.deepEqual(store.status().ready, false);
  assert.equal(store.table, undefined);
  assert.equal(store.status().lastErrorCategory, "network");
});

test("skips overlapping polls", async () => {
  const store = new AtomicRouteStore(policy);
  let resolveFetch!: (result: RegistryFetchResult) => void;
  const pendingFetch = new Promise<RegistryFetchResult>((resolve) => {
    resolveFetch = resolve;
  });
  const poller = createPoller(store, async () => await pendingFetch);

  const firstPoll = poller.pollOnce();
  assert.equal(await poller.pollOnce(), "overlap-skipped");
  resolveFetch({ kind: "snapshot", etag: '"routes-v1"', snapshot: createSnapshot(1) });
  assert.equal(await firstPoll, "updated");
});

test("HTTP 304 keeps the installed table and refreshes poll telemetry", async () => {
  const store = new AtomicRouteStore(policy);
  let requestedEtag: string | undefined;
  const results: RegistryFetchResult[] = [
    { kind: "snapshot", etag: '"routes-v1"', snapshot: createSnapshot(1) },
    { kind: "not-modified", etag: '"routes-v1"' },
  ];
  const poller = createPoller(store, async (etag) => {
    requestedEtag = etag;
    const result = results.shift();
    assert.ok(result);
    return result;
  });

  assert.equal(await poller.pollOnce(), "updated");
  const installed = store.table;
  assert.equal(await poller.pollOnce(), "not-modified");
  assert.equal(requestedEtag, '"routes-v1"');
  assert.equal(store.table, installed);
  assert.equal(store.status().lastPollResult, "not-modified");
});

test("outage after startup preserves last-known-good routing", async () => {
  const store = new AtomicRouteStore(policy);
  let outage = false;
  const poller = createPoller(store, async () => {
    if (outage) throw new RegistryClientError("network", "connection refused");
    return { kind: "snapshot", etag: '"routes-v1"', snapshot: createSnapshot(1) };
  });

  assert.equal(await poller.pollOnce(), "updated");
  outage = true;
  assert.equal(await poller.pollOnce(), "failed");
  assert.equal(store.status().ready, true);
  assert.equal(store.status().lastErrorCategory, "network");
  assert.equal(store.table?.match("/risk")?.active, true);
});

test("an active=false update atomically changes route enforcement", async () => {
  const store = new AtomicRouteStore(policy);
  const results: RegistryFetchResult[] = [
    { kind: "snapshot", etag: '"routes-v1"', snapshot: createSnapshot(1, true) },
    { kind: "snapshot", etag: '"routes-v2"', snapshot: createSnapshot(2, false) },
  ];
  const poller = createPoller(store, async () => {
    const result = results.shift();
    assert.ok(result);
    return result;
  });

  await poller.pollOnce();
  assert.equal(store.table?.match("/risk")?.active, true);
  await poller.pollOnce();
  assert.equal(store.table?.version, 2);
  assert.equal(store.table?.match("/risk")?.active, false);
});
