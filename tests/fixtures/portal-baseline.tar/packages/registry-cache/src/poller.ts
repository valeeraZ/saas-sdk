import { RegistryClientError, RegistryHttpClient } from "./client.ts";
import { AtomicRouteStore, StaleSnapshotError } from "./store.ts";
import type { RegistryErrorCategory } from "./types.ts";

export type PollOutcome = "updated" | "not-modified" | "failed" | "overlap-skipped";

type Timer = ReturnType<typeof setTimeout>;

export type RegistryPollerOptions = Readonly<{
  minIntervalMs: number;
  maxIntervalMs: number;
  random?: () => number;
  onError?: (category: RegistryErrorCategory, error: unknown) => void;
}>;

export class RegistryPoller {
  readonly #client: Pick<RegistryHttpClient, "fetchSnapshot">;
  readonly #store: AtomicRouteStore;
  readonly #options: Required<Pick<RegistryPollerOptions, "minIntervalMs" | "maxIntervalMs">> &
    Omit<RegistryPollerOptions, "minIntervalMs" | "maxIntervalMs">;
  #timer: Timer | undefined;
  #controller: AbortController | undefined;
  #running = false;

  constructor(
    client: Pick<RegistryHttpClient, "fetchSnapshot">,
    store: AtomicRouteStore,
    options: RegistryPollerOptions,
  ) {
    if (
      !Number.isSafeInteger(options.minIntervalMs) ||
      !Number.isSafeInteger(options.maxIntervalMs) ||
      options.minIntervalMs < 1 ||
      options.maxIntervalMs < options.minIntervalMs
    ) {
      throw new Error("Registry poll interval must be positive and max must be >= min");
    }
    this.#client = client;
    this.#store = store;
    this.#options = options;
  }

  async pollOnce(): Promise<PollOutcome> {
    if (!this.#store.beginPoll()) return "overlap-skipped";
    const controller = new AbortController();
    this.#controller = controller;
    try {
      const result = await this.#client.fetchSnapshot(this.#store.etag, controller.signal);
      if (result.kind === "not-modified") {
        this.#store.notModified(result.etag);
        return "not-modified";
      }
      this.#store.install(result.snapshot, result.etag);
      return "updated";
    } catch (error) {
      const category = this.#categorize(error);
      this.#store.fail(category);
      this.#options.onError?.(category, error);
      return "failed";
    } finally {
      if (this.#controller === controller) this.#controller = undefined;
    }
  }

  start(): void {
    if (this.#running) return;
    this.#running = true;
    this.#schedule();
  }

  stop(): void {
    this.#running = false;
    if (this.#timer) clearTimeout(this.#timer);
    this.#timer = undefined;
    this.#controller?.abort();
  }

  #schedule(): void {
    if (!this.#running) return;
    const random = Math.min(1, Math.max(0, (this.#options.random ?? Math.random)()));
    const delay = Math.round(
      this.#options.minIntervalMs +
        random * (this.#options.maxIntervalMs - this.#options.minIntervalMs),
    );
    this.#timer = setTimeout(async () => {
      await this.pollOnce();
      this.#schedule();
    }, delay);
    this.#timer.unref?.();
  }

  #categorize(error: unknown): RegistryErrorCategory {
    if (error instanceof RegistryClientError || error instanceof StaleSnapshotError) {
      return error.category;
    }
    if (error instanceof SyntaxError) return "parse";
    if (error instanceof Error && error.message.includes("304 before")) return "protocol";
    return "validation";
  }
}
