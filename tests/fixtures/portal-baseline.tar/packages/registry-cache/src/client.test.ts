import assert from "node:assert/strict";
import test from "node:test";

import { RegistryClientError, RegistryHttpClient } from "./client.ts";

const config = {
  endpoint: "http://registry.test/internal/saas/registry/routes",
  timeoutMs: 50,
  responseSizeLimitBytes: 1_024,
} as const;

test("sends If-None-Match and handles HTTP 304", async () => {
  let receivedHeader: string | null = null;
  const client = new RegistryHttpClient(config, async (_input, init) => {
    receivedHeader = new Headers(init?.headers).get("if-none-match");
    return new Response(null, { status: 304, headers: { etag: '"routes-v1"' } });
  });

  const result = await client.fetchSnapshot('"routes-v1"');
  assert.equal(receivedHeader, '"routes-v1"');
  assert.deepEqual(result, { kind: "not-modified", etag: '"routes-v1"' });
});

test("classifies invalid JSON, oversized responses, and timeouts", async (t) => {
  await t.test("invalid JSON", async () => {
    const client = new RegistryHttpClient(config, async () =>
      new Response("not json", { headers: { etag: '"routes-v1"' } }),
    );
    await assert.rejects(
      client.fetchSnapshot(),
      (error: unknown) =>
        error instanceof RegistryClientError && error.category === "parse",
    );
  });

  await t.test("response size", async () => {
    const client = new RegistryHttpClient(
      { ...config, responseSizeLimitBytes: 4 },
      async () => new Response("12345", { headers: { etag: '"routes-v1"' } }),
    );
    await assert.rejects(
      client.fetchSnapshot(),
      (error: unknown) =>
        error instanceof RegistryClientError && error.category === "response-too-large",
    );
  });

  await t.test("timeout", async () => {
    const client = new RegistryHttpClient(
      { ...config, timeoutMs: 5 },
      async (_input, init) =>
        await new Promise<Response>((_resolve, reject) => {
          init?.signal?.addEventListener(
            "abort",
            () => reject(new DOMException("aborted", "AbortError")),
            { once: true },
          );
        }),
    );
    await assert.rejects(
      client.fetchSnapshot(),
      (error: unknown) =>
        error instanceof RegistryClientError && error.category === "timeout",
    );
  });
});

test("requires successful responses to include ETag", async () => {
  const client = new RegistryHttpClient(config, async () =>
    Response.json({ version: 1, generatedAt: new Date().toISOString(), routes: [] }),
  );
  await assert.rejects(
    client.fetchSnapshot(),
    (error: unknown) =>
      error instanceof RegistryClientError && error.category === "protocol",
  );
});
