import assert from "node:assert/strict";
import test from "node:test";

import { buildUpstreamUrl, ImmutableRouteTable } from "./snapshot.ts";
import type { RouteSnapshot } from "./types.ts";
import {
  validateCatalogSnapshot,
  validateFrontendTarget,
  validateSnapshot,
} from "./validation.ts";

const snapshot: RouteSnapshot = {
  version: 1,
  generatedAt: "2026-07-12T00:00:00Z",
  routes: [
    { appName: "app", basePath: "/app", frontendTarget: "https://app.company.net", active: true },
    { appName: "app-admin", basePath: "/app-admin", frontendTarget: "https://admin.company.net", active: false },
  ],
};

const policy = { allowedHosts: [".company.net"] } as const;

test("matches only complete basePath segments", () => {
  const table = new ImmutableRouteTable(validateSnapshot(snapshot, policy));
  assert.equal(table.match("/app/deep")?.appName, "app");
  assert.equal(table.match("/app-admin")?.appName, "app-admin");
  assert.equal(table.match("/application"), undefined);
});

test("preserves pathname and query when building the upstream URL", () => {
  const route = validateSnapshot(snapshot, policy).routes[0];
  const target = buildUpstreamUrl(route, "/app/reports", "?period=30d&owner=a");
  assert.equal(target.href, "https://app.company.net/app/reports?period=30d&owner=a");
});

test("rejects unsafe target shapes and hosts", () => {
  assert.throws(
    () => validateFrontendTarget("http://169.254.169.254/latest", policy),
    /disallowed protocol|without path/,
  );
  assert.throws(
    () => validateFrontendTarget("https://example.com", policy),
    /not allowlisted/,
  );
  assert.throws(
    () => validateFrontendTarget("https://user:secret@app.company.net", policy),
    /credentials/,
  );
  assert.equal(
    validateFrontendTarget("https://app.company.net", {
      ...policy,
      allowedPorts: ["443"],
    }),
    "https://app.company.net",
  );
});

test("rejects duplicate and reserved routes atomically", () => {
  assert.throws(
    () => validateSnapshot({ ...snapshot, routes: [{ ...snapshot.routes[0], basePath: "/admin" }] }, policy),
    /reserved basePath/,
  );
  assert.throws(
    () => validateSnapshot({ ...snapshot, routes: [snapshot.routes[0], snapshot.routes[0]] }, policy),
    /Duplicate appName/,
  );
});

test("accepts only browser-safe Registry catalog fields", () => {
  const catalog = validateCatalogSnapshot({
    version: 2,
    apps: [
      {
        appName: "risk-dashboard",
        name: "Risk Dashboard",
        description: "Risk reports",
        logo: "ChartBar",
        basePath: "/risk",
        active: true,
      },
    ],
  });
  assert.equal(catalog.apps[0]?.name, "Risk Dashboard");
  assert.throws(
    () =>
      validateCatalogSnapshot({
        ...catalog,
        apps: [
          {
            ...catalog.apps[0],
            frontendTarget: "https://risk.company.net",
          },
        ],
      }),
    /server-only or unknown field/,
  );
});
